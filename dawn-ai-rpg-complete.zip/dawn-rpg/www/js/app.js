/**
 * DAWN AI RPG — App Controller
 * Wires DawnEngine + DawnAILayer + UI DOM together.
 * Loaded last after engine.js and ai.js.
 */

"use strict";

(function () {
  // ── Wait for DOM ───────────────────────────────────────────
  document.addEventListener("DOMContentLoaded", initApp);

  // ── Global refs ────────────────────────────────────────────
  let gameState, dawnAI;

  // ═══════════════════════════════════════════════════════════
  // INIT
  // ═══════════════════════════════════════════════════════════
  async function initApp() {
    const E = window.DawnEngine;
    const A = window.DawnAILayer;
    if (!E || !A) {
      console.error("Engine or AI layer not loaded.");
      return;
    }

    gameState = new E.GameState();
    dawnAI    = new A.DawnAI(gameState, {
      narrative: {
        useWebLLM:        true,
        webLLMModel:      "Llama-3.1-8B-Instruct-q4f32_1-MLC",
        claudeApiEnabled: false,  // set true + add API key to enable Claude fallback
        maxTokens:        400,
        temperature:      0.85,
      },
      image: {
        backend: "pollinations",
        width:   512,
        height:  512,
      },
    });

    // ── AI event hooks ────────────────────────────────────────
    dawnAI.onNarrative = (text) => appendNarrative(text, "ai-text");
    dawnAI.onMessage   = (msg)  => appendNarrative(msg,  "system-text");
    dawnAI.onLoading   = (bool) => setLoading(bool);
    dawnAI.onImageReady = (id, url, type) => handleImageReady(id, url, type);
    dawnAI.onEvent      = (ev)  => handleGameEvent(ev);

    // ── Engine event hooks ────────────────────────────────────
    gameState.on("combatStarted", ({ enemies }) => {
      appendNarrative(`⚔ Combat begins! ${enemies.map(e => e.name).join(", ")} ${enemies.length > 1 ? "appear" : "appears"}!`, "fail-text");
    });
    gameState.on("combatVictory", ({ loot }) => {
      appendNarrative("✦ Victory! Enemies defeated.", "success-text");
      loot.forEach(l => appendNarrative(`  Loot: ${l.enemyName} dropped rarity-${l.rarity} item + ${l.goldDropped} copper.`, "system-text"));
      closeCombatUI();
    });
    gameState.on("combatDefeated", () => {
      appendNarrative("✕ Defeated... the world fades to black.", "fail-text");
    });

    // ── Screen navigation ─────────────────────────────────────
    bindNavButtons();
    bindCreatorUI();
    bindGameHUD();
    bindSaveSlots();
    bindOverlays();

    // ── Model load on first arrival at game screen ─────────────
    // (deferred so menu loads instantly)

    updateSaveSlotDisplay();
    console.log("Dawn App ready. Engine v" + E.VERSION);
  }

  // ═══════════════════════════════════════════════════════════
  // SCREEN NAVIGATION
  // ═══════════════════════════════════════════════════════════
  function showScreen(id) {
    document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
    const s = document.getElementById(id);
    if (s) s.classList.add("active");
  }

  function openOverlay(id) { document.getElementById(id)?.classList.add("active"); }
  function closeOverlay(id) { document.getElementById(id)?.classList.remove("active"); }

  // Expose to inline HTML onclick
  window.showScreen  = showScreen;
  window.openOverlay = openOverlay;
  window.closeOverlay = closeOverlay;

  // ═══════════════════════════════════════════════════════════
  // SAVE SLOT DISPLAY
  // ═══════════════════════════════════════════════════════════
  function updateSaveSlotDisplay() {
    const E = window.DawnEngine;
    const slots = E.SaveEngine.listSlots();
    slots.forEach((slot, i) => {
      const el = document.querySelector(`[data-slot="${i}"]`);
      if (!el) return;
      if (slot.empty) {
        el.classList.add("empty");
        el.querySelector(".slot-char-name").textContent = "— Empty —";
        el.querySelector(".slot-detail-level").textContent = "";
        el.querySelector(".slot-detail-loc").textContent = "";
      } else {
        el.classList.remove("empty");
        el.querySelector(".slot-char-name").textContent = slot.characterName;
        el.querySelector(".slot-detail-level").textContent = `⚔ Lv. ${slot.level}`;
        el.querySelector(".slot-detail-loc").textContent = `📍 (${slot.location})`;
      }
    });
  }

  function bindSaveSlots() {
    document.querySelectorAll("[data-slot-load]").forEach(btn => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.slotLoad);
        const result = gameState.load(idx);
        if (result.success) {
          showScreen("screen-game");
          updateHUD();
          appendNarrative("Game loaded. The world remembers you...", "system-text");
          dawnAI.init();
        } else {
          alert("Nothing to load in that slot.");
        }
      });
    });

    document.querySelectorAll("[data-slot-delete]").forEach(btn => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.slotDelete);
        if (confirm("Delete this save?")) {
          window.DawnEngine.SaveEngine.deleteSlot(idx);
          updateSaveSlotDisplay();
        }
      });
    });
  }

  // ═══════════════════════════════════════════════════════════
  // CREATOR UI
  // ═══════════════════════════════════════════════════════════
  function bindCreatorUI() {
    // Tab switching
    document.querySelectorAll(".creator-tab").forEach(tab => {
      tab.addEventListener("click", () => switchCreatorTab(tab));
    });

    // Stat allocation
    document.querySelectorAll(".stat-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const delta = btn.textContent.trim() === "+" ? 1 : -1;
        adjustStat(btn, delta);
      });
    });

    // Confirm & begin
    const beginBtn = document.getElementById("btn-begin");
    if (beginBtn) beginBtn.addEventListener("click", beginNewGame);

    // Review button → populate confirm screen
    const reviewBtn = document.getElementById("btn-review");
    if (reviewBtn) reviewBtn.addEventListener("click", populateConfirmScreen);
  }

  // Creator tab state
  const tabOrder = ["tab-identity", "tab-appearance", "tab-stats", "tab-gear"];
  function switchCreatorTab(clickedTab) {
    const tabs = document.querySelectorAll(".creator-tab");
    const idx  = Array.from(tabs).indexOf(clickedTab);
    tabs.forEach(t => t.classList.remove("active"));
    clickedTab.classList.add("active");
    document.querySelectorAll(".creator-content").forEach((c, i) => {
      c.style.display = i === idx ? "block" : "none";
    });
    document.querySelector(".creator-content:nth-child(1)").parentElement.scrollTop = 0;
  }

  window.switchCreatorTabByName = function(contentId) {
    const idx = tabOrder.indexOf(contentId);
    if (idx >= 0) {
      const tabs = document.querySelectorAll(".creator-tab");
      switchCreatorTab(tabs[idx]);
    }
  };

  // Stat allocation engine
  let pointsRemaining = 10;
  const statValues = {};

  function adjustStat(btn, delta) {
    const row    = btn.closest(".stat-row");
    const valEl  = row.querySelector(".stat-value");
    const statKey = row.dataset.stat;
    const current = parseInt(valEl.textContent) || 5;

    if (delta > 0 && pointsRemaining <= 0) return;
    if (delta < 0 && current <= 1) return;
    if (delta > 0 && current >= 50) return;

    const newVal = current + delta;
    valEl.textContent = newVal;
    statValues[statKey] = newVal;
    pointsRemaining -= delta;

    const pr = document.getElementById("points-remaining");
    if (pr) {
      pr.textContent = pointsRemaining;
      pr.style.color = pointsRemaining === 0 ? "var(--ember)" : "var(--gold)";
    }
  }
  window.adjustStat = adjustStat;

  function gatherCreatorData() {
    const val = (id) => document.getElementById(id)?.value?.trim() || "";
    const sel = (id) => document.getElementById(id)?.value || "";

    return {
      character: {
        name:        val("char-name"),
        sex:         sel("char-sex"),
        race:        val("char-race"),
        age:         val("char-age"),
        origin:      val("char-origin"),
        occupation:  val("char-occupation"),
        background:  val("char-background"),
        personality: val("char-personality"),
        fears:       val("char-fears"),
        goals:       val("char-goals"),
        morality:    val("char-morality"),
        appearance: {
          bodyType:       val("app-body"),
          height:         val("app-height"),
          skinTone:       val("app-skin"),
          hairStyle:      val("app-hair"),
          eyeColor:       val("app-eyes"),
          marks:          val("app-marks"),
          facialFeatures: val("app-face"),
          clothingStyle:  val("app-clothing"),
          voiceStyle:     val("app-voice"),
          accessories:    val("app-accessories"),
          aura:           val("app-aura"),
        },
      },
      playerStats: {
        luck:         statValues["luck"]         || 5,
        agility:      statValues["agility"]      || 5,
        charisma:     statValues["charisma"]     || 5,
        wisdom:       statValues["wisdom"]       || 5,
        perception:   statValues["perception"]   || 5,
        intelligence: statValues["intelligence"] || 5,
        strength:     statValues["strength"]     || 5,
        constitution: statValues["constitution"] || 5,
      },
      petStats: {
        luck:         statValues["pet-luck"]         || 5,
        agility:      statValues["pet-agility"]      || 5,
        strength:     statValues["pet-strength"]     || 5,
        constitution: statValues["pet-constitution"] || 5,
        charisma:     5, wisdom: 5, perception: 5, intelligence: 5,
      },
      petName:          val("pet-name"),
      petSpecies:       val("pet-species"),
      petAppearance:    val("pet-appearance"),
      petPersonality:   val("pet-personality"),
      petBond:          val("pet-bond"),
      startingWeapon:   val("gear-weapon"),
      startingArmor:    val("gear-armor"),
      startingTool:     val("gear-tool"),
      startingCurrency: sel("gear-currency"),
    };
  }

  function populateConfirmScreen() {
    const data = gatherCreatorData();
    const c    = data.character;
    const set  = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val || "—"; };

    set("sum-name",   c.name);   set("sum-sex",  c.sex);
    set("sum-race",   c.race);   set("sum-age",  c.age);
    set("sum-origin", c.origin); set("sum-class", c.occupation);
    set("sum-pet",    data.petName + " (" + data.petSpecies + ")");
    set("sum-weapon", data.startingWeapon);
    set("sum-armor",  data.startingArmor);

    Object.entries(data.playerStats).forEach(([k, v]) => {
      const el = document.getElementById("sum-stat-" + k);
      if (el) el.textContent = v;
    });

    showScreen("screen-confirm");
  }

  async function beginNewGame() {
    const data = gatherCreatorData();
    if (!data.character.name) {
      alert("Please enter a character name."); return;
    }

    showScreen("screen-generating");
    startGenerationAnimation();

    try {
      const { player, pet } = gameState.newGame(data, 0);
      updateHUD();

      // Init AI in background
      await dawnAI.init();

      // Generate opening narrative
      const opening = await dawnAI.narrative.generate(
        DawnAILayer.ContextBuilder.buildSystemPrompt(gameState),
        [],
        `Begin the adventure. ${player.name} starts their journey at the edge of a wilderness. ` +
        `They have ${pet.name} (${pet.species || "their companion"}) with them. ` +
        `Describe the opening scene vividly in 3-4 sentences. Make it compelling.`
      );
      const { cleanText } = DawnAILayer.OutputParser.parse(opening);

      // Transition to game
      await new Promise(r => setTimeout(r, 4000)); // let animation play
      document.getElementById("screen-generating").classList.remove("active");
      showScreen("screen-game");
      appendNarrative(cleanText, "ai-text");

      // Generate character image async
      dawnAI.generateCharacterImage(player);

    } catch (err) {
      console.error("New game error:", err);
      document.getElementById("screen-generating").classList.remove("active");
      showScreen("screen-game");
      appendNarrative("Your journey begins in the darkness... (AI model loading)", "system-text");
    }
  }

  // ═══════════════════════════════════════════════════════════
  // GENERATION ANIMATION
  // ═══════════════════════════════════════════════════════════
  const genSteps = [
    "Seeding the world...", "Generating terrain grid...",
    "Placing towns and dungeons...", "Writing your first location...",
    "Summoning your companion...", "Weaving the opening narrative...", "Dawn breaks...",
  ];

  function startGenerationAnimation() {
    let step = 0;
    const el = document.getElementById("gen-step-text");
    const interval = setInterval(() => {
      if (el && step < genSteps.length) {
        el.textContent = genSteps[step++];
      } else {
        clearInterval(interval);
      }
    }, 600);
  }

  // ═══════════════════════════════════════════════════════════
  // GAME HUD
  // ═══════════════════════════════════════════════════════════
  function bindGameHUD() {
    // D-pad
    document.querySelectorAll(".dpad-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const dir = btn.dataset.dir;
        if (dir) handleMove(dir);
      });
    });

    // Narrative input
    const input = document.getElementById("narrative-input");
    if (input) {
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") sendNarrative(); });
    }
    document.getElementById("narrative-send")?.addEventListener("click", sendNarrative);

    // Save button
    document.getElementById("hud-save")?.addEventListener("click", () => {
      gameState.save();
      appendNarrative("💾 Game saved.", "system-text");
    });

    // Party icons → character sheet
    document.querySelectorAll(".party-member[data-party-idx]").forEach(el => {
      el.addEventListener("click", () => {
        const idx = parseInt(el.dataset.partyIdx);
        showCharacterSheet(idx);
        openOverlay("overlay-char");
      });
    });

    // Long-press scene panel → map
    let pressTimer;
    const scenePanel = document.getElementById("scene-panel");
    if (scenePanel) {
      scenePanel.addEventListener("touchstart", () => { pressTimer = setTimeout(() => openOverlay("overlay-map"), 600); });
      scenePanel.addEventListener("touchend", () => clearTimeout(pressTimer));
      scenePanel.addEventListener("mousedown", () => { pressTimer = setTimeout(() => openOverlay("overlay-map"), 800); });
      scenePanel.addEventListener("mouseup", () => clearTimeout(pressTimer));
    }
  }

  async function handleMove(direction) {
    if (!gameState.party) return;
    await dawnAI.handleMovement(direction);
    updateHUD();
    generateWorldGridMap();
  }

  async function sendNarrative() {
    const input = document.getElementById("narrative-input");
    const val   = input?.value?.trim();
    if (!val) return;
    appendNarrative(`> ${val}`, "system-text");
    input.value = "";

    // Check for built-in movement shortcuts
    const dir = { north: "N", south: "S", east: "E", west: "W",
                  "go north": "N", "go south": "S", "go east": "E", "go west": "W",
                  "move north": "N", "move south": "S", "move east": "E", "move west": "W" }[val.toLowerCase()];
    if (dir) { await handleMove(dir); return; }

    // Pass to AI
    await dawnAI.handlePlayerInput(val);
    updateHUD();
  }

  // ═══════════════════════════════════════════════════════════
  // HUD UPDATES
  // ═══════════════════════════════════════════════════════════
  function updateHUD() {
    const party = gameState.party;
    if (!party) return;

    // Update party icons
    party.members.forEach((member, i) => {
      const icon = document.querySelector(`.party-member[data-party-idx="${i}"]`);
      if (!icon) return;
      const hpPct = member.maxHp > 0 ? (member.hp / member.maxHp * 100) : 0;
      const fill  = icon.querySelector(".party-hp-fill");
      const name  = icon.querySelector(".party-name");
      const lvl   = icon.querySelector(".party-level");
      if (fill) fill.style.width = hpPct + "%";
      if (name) name.textContent = member.name?.split(" ")[0] || "?";
      if (lvl)  lvl.textContent  = member.level;

      // HP color
      if (fill) fill.style.background =
        hpPct > 50 ? "linear-gradient(90deg,#4caf50,#8bc34a)" :
        hpPct > 25 ? "linear-gradient(90deg,#ff9800,#ffc107)" :
                     "linear-gradient(90deg,#c94c1a,#e8701a)";
    });

    // Update coords
    const coords = document.querySelector(".scene-coords");
    if (coords && gameState.world) {
      coords.textContent = `X: ${gameState.world.currentX} · Y: ${gameState.world.currentY}`;
    }

    // Scene image
    const tile = gameState.world?.currentTile;
    if (tile?.imageUrl) {
      const sceneEl = document.querySelector(".scene-image");
      if (sceneEl) sceneEl.style.backgroundImage = `url(${tile.imageUrl})`;
    }

    // Location label
    const locEl = document.querySelector(".scene-location");
    if (locEl && tile) {
      const icons = { wilderness: "🌲", town: "🏘", dungeon: "💀", protection: "🛡", dungeon_interior: "⚔" };
      locEl.textContent = (icons[tile.type] || "📍") + " " + (tile.description?.slice(0, 60) || `(${tile.x}, ${tile.y})`);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // NARRATIVE BOX
  // ═══════════════════════════════════════════════════════════
  function appendNarrative(text, cls = "ai-text") {
    const scroll = document.getElementById("narrative-scroll");
    if (!scroll) return;
    const p = document.createElement("p");
    p.className = cls;
    p.textContent = text;
    scroll.appendChild(p);
    scroll.scrollTop = scroll.scrollHeight;

    // Keep scroll height sane (remove old entries)
    while (scroll.children.length > 100) scroll.removeChild(scroll.firstChild);
  }

  function setLoading(bool) {
    const input = document.getElementById("narrative-input");
    const send  = document.getElementById("narrative-send");
    if (input) input.disabled = bool;
    if (send)  send.disabled  = bool;
    if (bool) appendNarrative("...", "system-text");
  }

  // ═══════════════════════════════════════════════════════════
  // CHARACTER SHEET
  // ═══════════════════════════════════════════════════════════
  function showCharacterSheet(memberIdx = 0) {
    const member = gameState.party?.members[memberIdx];
    if (!member) return;

    // Name / class
    const nameEl = document.querySelector("#overlay-char .char-name-display");
    const classEl = document.querySelector("#overlay-char .char-class");
    if (nameEl)  nameEl.textContent  = member.name;
    if (classEl) classEl.textContent = `Lv. ${member.level} · ${member.occupation || "Wanderer"}`;

    // Resource bars
    const bars = { hp: [member.hp, member.maxHp], mp: [member.magic, member.maxMagic], st: [member.stamina, member.maxStamina] };
    Object.entries(bars).forEach(([key, [cur, max]]) => {
      const fill = document.querySelector(`.bar-${key} .bar-fill`);
      const val  = document.querySelector(`.bar-${key}`)?.nextElementSibling;
      if (fill) fill.style.width = (max > 0 ? cur / max * 100 : 0) + "%";
      if (val)  val.textContent  = `${cur} / ${max}`;
    });

    // Stat cards
    Object.entries(member.stats).forEach(([stat, val]) => {
      const el = document.getElementById("stat-card-" + stat);
      if (el) el.textContent = val;
    });

    // Portrait image
    const portrait = document.querySelector("#overlay-char .char-portrait");
    if (portrait && member.compositeImageUrl) {
      portrait.style.backgroundImage = `url(${member.compositeImageUrl})`;
      portrait.style.backgroundSize  = "cover";
      portrait.textContent = "";
    } else if (portrait && member.baseImageUrl) {
      portrait.style.backgroundImage = `url(${member.baseImageUrl})`;
      portrait.style.backgroundSize  = "cover";
      portrait.textContent = "";
    }
  }

  function switchCharTab(tab, contentId) {
    document.querySelectorAll(".char-tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    document.querySelectorAll("#overlay-char .char-content").forEach(c => c.style.display = "none");
    const el = document.getElementById(contentId);
    if (el) el.style.display = "block";
  }
  window.switchCharTab = switchCharTab;

  // ═══════════════════════════════════════════════════════════
  // WORLD MAP GRID
  // ═══════════════════════════════════════════════════════════
  function generateWorldGridMap() {
    const grid     = document.getElementById("world-grid");
    if (!grid || !gameState.world) return;
    const SIZE     = 9;
    const HALF     = Math.floor(SIZE / 2);
    const cx       = gameState.world.currentX;
    const cy       = gameState.world.currentY;

    grid.innerHTML = "";

    for (let row = HALF; row >= -HALF; row--) {
      for (let col = -HALF; col <= HALF; col++) {
        const wx   = cx + col;
        const wy   = cy + row;
        const tile = gameState.world.getTile(wx, wy);
        const cell = document.createElement("div");
        cell.className = "grid-cell";

        if (col === 0 && row === 0) {
          cell.classList.add("current");
          cell.textContent = "◈";
        } else if (tile) {
          cell.classList.add("visited");
          if (tile.type === "town")    { cell.classList.add("town");    cell.textContent = "🏘"; cell.style.fontSize = "9px"; }
          if (tile.type === "dungeon") { cell.classList.add("dungeon"); cell.textContent = "💀"; cell.style.fontSize = "9px"; }
          if (tile.hasDungeon)         cell.textContent = "🏚";
        }

        cell.title = `(${wx}, ${wy}) ${tile?.type || "unexplored"}`;
        grid.appendChild(cell);
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // COMBAT UI
  // ═══════════════════════════════════════════════════════════
  function handleGameEvent(ev) {
    if (ev.type === "combatStart") {
      const E = window.DawnEngine;
      // Spawn a simple enemy based on spawn type
      const enemy = new E.Character({
        name:  ev.data.creatureName || "Hostile Creature",
        stats: E.createBaseStats ? E.createBaseStats() : { luck:5,agility:5,charisma:5,wisdom:5,perception:5,intelligence:5,strength:5,constitution:5 },
        level: gameState.party?.player?.level || 1,
      });
      const pools = E.StatEngine.computeMaxPools(enemy.stats, enemy.level);
      enemy.hp = pools.maxHp; enemy.maxHp = pools.maxHp;
      enemy.stamina = pools.maxStamina; enemy.maxStamina = pools.maxStamina;
      gameState.startCombat([enemy]);
      showCombatUI(enemy);
    }
  }

  function showCombatUI(enemy) {
    // Append a combat panel to narrative
    appendNarrative(`\n⚔ COMBAT MODE — ${enemy.name} (HP: ${enemy.hp})`, "fail-text");
    appendNarrative(`Type: "attack", "flee", or a spell name`, "system-text");
  }

  function closeCombatUI() {
    appendNarrative("Combat over.", "system-text");
  }

  // ═══════════════════════════════════════════════════════════
  // IMAGE READY HANDLER
  // ═══════════════════════════════════════════════════════════
  function handleImageReady(id, url, type) {
    if (type === "scene") {
      const sceneEl = document.querySelector(".scene-image");
      if (sceneEl && url) {
        sceneEl.style.backgroundImage = `url(${url})`;
        sceneEl.style.backgroundSize  = "cover";
        sceneEl.style.backgroundPosition = "center";
        const placeholder = sceneEl.querySelector(".scene-placeholder");
        if (placeholder) placeholder.style.display = "none";
      }
    }
    if ((type === "character_base" || type === "character_composite") && id) {
      // Find party member with this ID and refresh portrait if sheet open
      const member = gameState.party?.members.find(m => m.id === id);
      if (member) {
        // Update party icon
        const partyIdx = gameState.party.members.indexOf(member);
        const icon = document.querySelector(`.party-member[data-party-idx="${partyIdx}"] .party-icon`);
        if (icon && url) {
          icon.style.backgroundImage = `url(${url})`;
          icon.style.backgroundSize  = "cover";
          icon.textContent = "";
        }
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // OVERLAYS / MISC
  // ═══════════════════════════════════════════════════════════
  function bindNavButtons() {
    // handled via inline onclick in HTML + window.showScreen
  }

  function bindOverlays() {
    // Close on backdrop click (already handled inline in HTML)
    // Inventory item long-press → AI description
    document.querySelectorAll(".inv-item:not(.empty)").forEach((el, i) => {
      let t;
      el.addEventListener("touchstart", () => {
        t = setTimeout(async () => {
          const item = gameState.party?.inventory.items[i];
          if (!item) return;
          const desc = await dawnAI.getItemDescription(item);
          showItemTooltip(el, item, desc);
        }, 600);
      });
      el.addEventListener("touchend", () => clearTimeout(t));
      el.addEventListener("click", () => showItemTooltip(el, gameState.party?.inventory.items[i]));
    });

    // Map open
    document.getElementById("hud-map")?.addEventListener("click", () => {
      generateWorldGridMap();
      openOverlay("overlay-map");
    });
  }

  function showItemTooltip(el, item, desc) {
    if (!item) return;
    const tt = document.getElementById("item-tooltip");
    if (!tt) return;
    document.getElementById("tt-name").textContent    = item.name;
    document.getElementById("tt-name").style.color    = item.rarityData?.color || "var(--rare1)";
    document.getElementById("tt-rarity").textContent  = item.rarityData?.name || "Common";
    document.getElementById("tt-rarity").style.color  = item.rarityData?.color || "var(--rare1)";
    document.getElementById("tt-desc").textContent    = desc || item.description || "";
    document.getElementById("tt-stat").innerHTML      = item.weaponDmg ? `ATK: <span>+${item.weaponDmg}</span>` : "";
    document.getElementById("tt-dur").textContent     = `Durability: ${item.durability?.current}/${item.durability?.max}`;

    const rect = el.getBoundingClientRect();
    tt.style.left = Math.min(rect.left, window.innerWidth - 220) + "px";
    tt.style.top  = (rect.top - 130) + "px";
    tt.classList.add("active");
    setTimeout(() => tt.classList.remove("active"), 3000);
  }
  window.showItemTooltip = showItemTooltip;

  // ═══════════════════════════════════════════════════════════
  // DICE ROLL UI (called from engine events or manually)
  // ═══════════════════════════════════════════════════════════
  window.triggerDiceRoll = function(statKey = "agility", difficulty = 1.0) {
    const E = window.DawnEngine;
    const player = gameState.party?.player;
    if (!player) return;

    const stat   = player.stats[statKey] || 5;
    const result = E.DiceEngine.rollCheck(stat, player.level, difficulty);

    document.getElementById("dice-target").textContent = result.target;
    document.getElementById("dice-max").textContent    = result.maxRoll;
    document.getElementById("dice-number").textContent = result.roll;

    const resEl  = document.getElementById("dice-result");
    const descEl = document.getElementById("dice-desc");
    const faceEl = document.getElementById("dice-face");

    faceEl.style.animation = "none";
    void faceEl.offsetHeight;
    faceEl.style.animation = "dice-spin 0.6s ease-out";

    if (result.success) {
      resEl.className   = "dice-result success";
      resEl.textContent = result.critSuccess ? "✦ CRITICAL SUCCESS ✦" : "✦ SUCCESS ✦";
      descEl.textContent = result.critSuccess ? "A legendary feat! The world stands witness." : "You succeed.";
    } else {
      resEl.className   = "dice-result failure";
      resEl.textContent = result.critFail ? "✕ CRITICAL FAILURE ✕" : "✕ FAILURE ✕";
      descEl.textContent = result.critFail ? "A catastrophic failure." : "The attempt falters.";
    }

    openOverlay("overlay-dice");

    // Narrate via AI
    dawnAI.narrateSkillCheck(statKey, difficulty, result).catch(console.warn);
    return result;
  };

})();
