/**
 * DAWN AI RPG — AI Integration Layer
 *
 * Handles:
 *  1. Narrative AI  — text generation via local WebLLM (primary) or
 *                     Claude API (fallback when WebLLM unavailable)
 *  2. Image AI      — base character/item image generation +
 *                     composite equip renders (via canvas + prompt queue)
 *  3. Parser        — detects game triggers in AI output (sell, learn, enter, etc.)
 *  4. Context       — builds stat-aware prompts that keep the AI grounded in game rules
 */

"use strict";

// ── Bring in engine constants when loaded as a module ──────────
const _E = (typeof window !== "undefined" && window.DawnEngine) || {};
const { DIFFICULTY, GRID_TYPES, Util: _Util } = _E;

// ═══════════════════════════════════════════════════════════════
// 1. NARRATIVE AI MANAGER
// ═══════════════════════════════════════════════════════════════

class NarrativeAI {
  /**
   * @param {Object} config
   *   useWebLLM        boolean  — attempt WebLLM/WebGPU first
   *   webLLMModel      string   — e.g. "Llama-3-8B-Instruct-q4f32_1"
   *   claudeApiEnabled boolean  — allow Claude API fallback
   *   maxTokens        number   — max response tokens
   *   temperature      number   — 0.0–1.0
   */
  constructor(config = {}) {
    this.useWebLLM        = config.useWebLLM        ?? true;
    this.webLLMModel      = config.webLLMModel      ?? "Llama-3.1-8B-Instruct-q4f32_1-MLC";
    this.claudeApiEnabled = config.claudeApiEnabled ?? false;
    this.maxTokens        = config.maxTokens        ?? 400;
    this.temperature      = config.temperature      ?? 0.85;

    this._engine    = null;  // WebLLM engine instance
    this._ready     = false;
    this._loading   = false;
    this._listeners = { progress: [], ready: [], error: [] };
  }

  on(event, fn) {
    (this._listeners[event] = this._listeners[event] || []).push(fn);
    return this;
  }
  _emit(event, data) { (this._listeners[event] || []).forEach(fn => fn(data)); }

  /** Load the local WebLLM model. Call once on startup. */
  async loadModel() {
    if (this._ready || this._loading) return;
    this._loading = true;

    if (this.useWebLLM && typeof window !== "undefined") {
      try {
        // Dynamic import of WebLLM (loaded via CDN in HTML)
        const webllm = window.webllm;
        if (!webllm) throw new Error("WebLLM not loaded on window.");

        this._engine = new webllm.MLCEngine();
        this._engine.setInitProgressCallback((report) => {
          this._emit("progress", { text: report.text, progress: report.progress });
        });

        await this._engine.reload(this.webLLMModel, {
          temperature: this.temperature,
          max_gen_len: this.maxTokens,
        });

        this._ready   = true;
        this._loading = false;
        this._emit("ready", { backend: "webllm" });
        return { backend: "webllm" };
      } catch (err) {
        console.warn("WebLLM failed, falling back:", err.message);
      }
    }

    // Fallback: mark as ready using Claude API or mock
    this._ready   = true;
    this._loading = false;
    this._emit("ready", { backend: this.claudeApiEnabled ? "claude" : "mock" });
    return { backend: this.claudeApiEnabled ? "claude" : "mock" };
  }

  /**
   * Generate narrative text.
   * @param {string}   systemPrompt  — game master context
   * @param {string[]} history       — previous messages [{role, content}]
   * @param {string}   userInput     — current player command
   * @returns {Promise<string>}
   */
  async generate(systemPrompt, history = [], userInput) {
    if (!this._ready) await this.loadModel();

    const messages = [
      { role: "system", content: systemPrompt },
      ...history,
      { role: "user",   content: userInput },
    ];

    // — WebLLM path —
    if (this._engine) {
      const reply = await this._engine.chat.completions.create({
        messages,
        temperature: this.temperature,
        max_tokens:  this.maxTokens,
        stream:      false,
      });
      return reply.choices[0].message.content;
    }

    // — Claude API fallback —
    if (this.claudeApiEnabled) {
      return await this._callClaudeAPI(messages);
    }

    // — Mock fallback (dev/demo) —
    return this._mockResponse(userInput);
  }

  async _callClaudeAPI(messages) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model:      "claude-sonnet-4-20250514",
        max_tokens: this.maxTokens,
        system:     messages.find(m => m.role === "system")?.content || "",
        messages:   messages.filter(m => m.role !== "system"),
      }),
    });
    const data = await res.json();
    return data.content?.map(b => b.text || "").join("") || "";
  }

  _mockResponse(input) {
    const lower = input.toLowerCase();
    if (lower.includes("attack") || lower.includes("fight"))
      return "You charge forward with your weapon raised! The creature snarls and lunges. [COMBAT_START]";
    if (lower.includes("look") || lower.includes("examine"))
      return "You survey your surroundings carefully. The landscape stretches out before you, full of mystery and hidden dangers.";
    if (lower.includes("north") || lower.includes("move"))
      return "You press onward. The path ahead winds between ancient stones covered in moss.";
    if (lower.includes("sell") || lower.includes("shop"))
      return "The merchant eyes your goods. 'Fair enough,' he mutters. [SELL_ITEM:rusty_sword:15s]";
    return "The world holds its breath as you consider your next move. What will you do?";
  }
}

// ═══════════════════════════════════════════════════════════════
// 2. CONTEXT BUILDER
//    Translates GameState → rich system prompt for the AI
// ═══════════════════════════════════════════════════════════════

const ContextBuilder = {
  /**
   * Build a full GM system prompt from current game state.
   * @param {Object} gameState - DawnEngine.GameState instance
   * @returns {string}
   */
  buildSystemPrompt(gameState) {
    const { party, world } = gameState;
    const player = party?.player;
    if (!player) return this._basePrompt();

    const tile    = world?.currentTile;
    const subStats = player.subStats;
    const pools    = { hp: player.hp, maxHp: player.maxHp, stamina: player.stamina, maxStamina: player.maxStamina, magic: player.magic, maxMagic: player.maxMagic };

    return `${this._basePrompt()}

## CURRENT PLAYER
Name: ${player.name}
Race: ${player.race || "Human"} | Sex: ${player.sex || "Unknown"} | Age: ${player.age || "?"}
Occupation: ${player.occupation || "Wanderer"}
Level: ${player.level} | XP: ${player.xp}
Background: ${player.background || "Unknown."}
Personality: ${player.personality || "Unknown."}
Goals: ${player.goals || "Unknown."}

## CURRENT RESOURCES
HP: ${pools.hp}/${pools.maxHp} | Stamina: ${pools.stamina}/${pools.maxStamina} | Magic: ${pools.magic}/${pools.maxMagic}

## MAIN STATS (Raw)
${this._statsBlock(player.stats)}

## KEY SUB-STATS (Active)
Dodge: ${(subStats.dodge_x * 100).toFixed(1)}% | Crit: ${(subStats.crit_plus * 100).toFixed(1)}% | Stealth: ${(subStats.stealth_x * 100).toFixed(1)}%
Persuade: ${(subStats.persuade_plus * 100).toFixed(1)}% | Barter: ${(subStats.barter_plus * 100).toFixed(1)}% | Taming: ${(subStats.taming_x * 100).toFixed(1)}%
Spell Power: ${(subStats.spell_dmg_x * 100).toFixed(1)}% | Melee Power: ${(subStats.attack_dmg_x * 100).toFixed(1)}%

## PARTY (${party.members.length}/4 members)
${party.members.map((m, i) => `  ${i + 1}. ${m.name} (Lv.${m.level} ${m.race || ""}) — HP: ${m.hp}/${m.maxHp}`).join("\n")}

## PETS & MOUNTS
${party.pets.length > 0 ? party.pets.map(p => `  ${p.pet.name} (${p.pet.species || "creature"}) Lv.${p.pet.level}`).join("\n") : "  None."}

## EQUIPPED ITEMS
${this._equipBlock(player.equipment)}

## CURRENT LOCATION
Grid: (${world?.currentX || 0}, ${world?.currentY || 0})
Type: ${tile?.type || "wilderness"}
${tile?.description ? `Scene: ${tile.description}` : "Scene: Unexplored territory."}
${world?.inDungeon ? `⚠ INSIDE DUNGEON — dungeon interior rules apply. Hostile rates: 80% creature, 10% humanoid, 10% exotic.` : ""}

## INVENTORY SNAPSHOT
Carry: ${party.inventory.currentWeight.toFixed(1)} / ${party.inventory.maxWeightLbs} lbs
Gold: ${party.inventory.currencyDisplay}
Items: ${party.inventory.items.map(i => i.name).join(", ") || "None."}

## WORLD STATE RULES (STRICT)
- Spawn rates — Wilderness: 80% passive, 15% neutral, 4% hostile creature, 1% hostile humanoid
- Dungeons: 80% hostile creature, 10% hostile humanoid, 10% exotic
- Towns: 100% passive, no random hostiles
- Protection zone (within 10 grids of origin): 99% neutral, 1% humanoid
- Guild swap only valid AT A GUILD GRID location
- Companion swap only valid AT A GUILD GRID location

## TRIGGER SYNTAX (embed in your response when events occur)
When any of these events happen, append the trigger tag ON ITS OWN LINE:
  [COMBAT_START:creature_name]       — hostile encounter begins
  [SELL_ITEM:item_id:amount_copper]  — item sold to NPC
  [BUY_ITEM:item_id:amount_copper]   — item bought from NPC
  [LEARN_SKILL:skill_name:cost_pct:base_damage] — player learns ability
  [LOOT_ITEM:item_rarity:item_name]  — item found/looted
  [TAME_PET:pet_species:pet_name]    — new pet tamed
  [GRID_DESC:description]            — persist this description to current tile
  [NPC_MET:npc_name:personality]     — new NPC encountered (save to town)
  [GOLD_GAINED:amount_copper]        — gold reward
  [DAMAGE_TAKEN:amount]              — player takes environmental damage
  [HEAL:amount]                      — player healed

## YOUR ROLE
You are the omniscient Game Master of Dawn. Narrate in second person ("you"). 
Descriptions should be vivid and atmospheric. 
Scale your narrative to dice roll outcomes: legendary success = epic description, narrow success = tense near-miss, failure = consequence.
Always check the player's Charisma before allowing NPCs to share secrets.
Always check Perception before revealing hidden details.
High Charisma NPCs are more friendly; low Charisma may result in hostile or dismissive reactions.
Keep responses under 150 words unless dramatic tension demands more.
`;
  },

  _basePrompt() {
    return `You are the Game Master of DAWN AI RPG — a dark fantasy open-world text RPG.
You maintain a persistent, lore-consistent world where every choice has consequences.
All stat checks, dice rolls, and game mechanics are handled externally. You receive their results and narrate accordingly.
You never break character. You never reveal system internals. You are the world.`;
  },

  _statsBlock(stats) {
    return Object.entries(stats)
      .map(([k, v]) => `  ${k.charAt(0).toUpperCase() + k.slice(1)}: ${v}`)
      .join(" | ");
  },

  _equipBlock(equipment) {
    return Object.entries(equipment)
      .filter(([, v]) => v !== null)
      .map(([slot, item]) => `  ${slot}: ${item.name} (${item.durability.current}/${item.durability.max} dur)`)
      .join("\n") || "  Nothing equipped.";
  },

  /**
   * Build a targeted prompt for a specific event (combat outcome, skill check, etc.)
   */
  buildEventPrompt(eventType, eventData) {
    switch (eventType) {
      case "skillCheck":
        return `A skill check just resolved:
Stat: ${eventData.statKey} (${eventData.statValue})
Roll: ${eventData.roll} / ${eventData.target} (max: ${eventData.maxRoll})
Result: ${eventData.success ? "SUCCESS" : "FAILURE"} — narrative weight: ${eventData.narrativeWeight}
Narrate the outcome in 2-3 sentences. Append any triggers needed.`;

      case "combatRound":
        return `Combat round ${eventData.turn} resolved:
${eventData.log.map(e => `  ${e.actor} → ${e.target}: ${e.damage} dmg${e.isCrit ? " (CRIT!)" : ""}`).join("\n")}
Narrate this combat exchange dramatically. 2-4 sentences. Include [DAMAGE_TAKEN:X] if player was hit.`;

      case "movement":
        return `The player moved ${eventData.direction} to grid (${eventData.x}, ${eventData.y}).
Tile type: ${eventData.tileType}
${eventData.spawnType ? `⚠ Spawn rolled: ${eventData.spawnType}` : "No encounter."}
Generate a 2-3 sentence atmospheric description of the new location, then append [GRID_DESC:your description here].`;

      case "shopEnter":
        return `The player has entered a shop in ${eventData.townName}.
Available items: ${JSON.stringify(eventData.shopInventory)}
Player Charisma: ${eventData.charisma} | Barter: ${(eventData.barter * 100).toFixed(1)}%
Describe the shop and shopkeeper in character.`;

      case "itemHover":
        return `Generate a lore-consistent description for this item:
Name: ${eventData.name}
Type: ${eventData.type}
Rarity: ${eventData.rarity}
Stats: ${JSON.stringify(eventData.stats)}
Write 1-2 sentences of flavor text, then one sentence of practical description. Total under 60 words.`;

      default:
        return `Narrate the current situation for the player.`;
    }
  },
};

// ═══════════════════════════════════════════════════════════════
// 3. OUTPUT PARSER
//    Scans AI text for trigger tags and converts them into game events
// ═══════════════════════════════════════════════════════════════

const OutputParser = {
  TRIGGER_RE: /\[([A-Z_]+)(?::([^\]]*))?\]/g,

  /**
   * Parse AI output, extract triggers, return clean text + event list.
   * @param {string} rawText
   * @returns {{ cleanText: string, events: Array<{type, args}> }}
   */
  parse(rawText) {
    const events   = [];
    const cleanText = rawText.replace(this.TRIGGER_RE, (match, type, argsStr) => {
      const args = (argsStr || "").split(":").map(s => s.trim());
      events.push(this._buildEvent(type, args));
      return ""; // strip trigger from visible text
    }).replace(/\s+\n/g, "\n").trim();

    return { cleanText, events };
  },

  _buildEvent(type, args) {
    switch (type) {
      case "COMBAT_START":
        return { type: "combatStart",   creatureName: args[0] || "Unknown Enemy" };
      case "SELL_ITEM":
        return { type: "sellItem",      itemId: args[0], amountCopper: parseInt(args[1]) || 0 };
      case "BUY_ITEM":
        return { type: "buyItem",       itemId: args[0], amountCopper: parseInt(args[1]) || 0 };
      case "LEARN_SKILL":
        return { type: "learnSkill",    skillName: args[0], costPct: parseFloat(args[1]) || 0.1, baseDamage: parseInt(args[2]) || 0 };
      case "LOOT_ITEM":
        return { type: "lootItem",      rarity: parseInt(args[0]) || 1, itemName: args[1] || "Unknown Item" };
      case "TAME_PET":
        return { type: "tamePet",       species: args[0], petName: args[1] || "Companion" };
      case "GRID_DESC":
        return { type: "persistGridDesc", description: args.join(":") };
      case "NPC_MET":
        return { type: "npcMet",        npcName: args[0], personality: args[1] };
      case "GOLD_GAINED":
        return { type: "goldGained",    amountCopper: parseInt(args[0]) || 0 };
      case "DAMAGE_TAKEN":
        return { type: "damageTaken",   amount: parseInt(args[0]) || 0 };
      case "HEAL":
        return { type: "heal",          amount: parseInt(args[0]) || 0 };
      default:
        return { type: "unknown",       raw: `[${type}:${args.join(":")}]` };
    }
  },

  /**
   * Apply parsed events to the GameState.
   * @param {Object[]} events
   * @param {Object}   gameState - DawnEngine.GameState
   * @param {Object}   callbacks - { onCombat, onLearnSkill, onLoot, onTame, onNpcMet, onMessage }
   */
  applyEvents(events, gameState, callbacks = {}) {
    const player    = gameState.party?.player;
    const inventory = gameState.party?.inventory;

    for (const ev of events) {
      switch (ev.type) {
        case "combatStart":
          callbacks.onCombat?.(ev);
          break;

        case "sellItem": {
          if (inventory) {
            inventory.removeItem(ev.itemId);
            inventory.addCurrency(ev.amountCopper);
            callbacks.onMessage?.(`Sold item for ${_Util?.formatCurrency?.(ev.amountCopper) || ev.amountCopper + " copper"}.`);
          }
          break;
        }

        case "buyItem": {
          if (inventory) {
            const result = inventory.spendCurrency(ev.amountCopper);
            if (!result.success) callbacks.onMessage?.("Not enough gold.");
            else callbacks.onMessage?.(`Purchased for ${ev.amountCopper} copper.`);
          }
          break;
        }

        case "learnSkill": {
          if (player) {
            const skill = {
              id:         `skill_${Date.now()}`,
              name:       ev.skillName,
              costPct:    ev.costPct,
              baseDamage: ev.baseDamage,
              learned:    Date.now(),
            };
            player.skills.push(skill);
            callbacks.onLearnSkill?.(skill);
            callbacks.onMessage?.(`Learned: ${ev.skillName}`);
          }
          break;
        }

        case "lootItem":
          callbacks.onLoot?.(ev);
          break;

        case "tamePet":
          callbacks.onTame?.(ev);
          break;

        case "persistGridDesc": {
          const tile = gameState.world?.currentTile;
          if (tile) tile.description = ev.description;
          break;
        }

        case "npcMet":
          callbacks.onNpcMet?.(ev);
          break;

        case "goldGained":
          inventory?.addCurrency(ev.amountCopper);
          break;

        case "damageTaken":
          if (player) player.hp = Math.max(0, player.hp - ev.amount);
          break;

        case "heal":
          if (player) player.hp = Math.min(player.maxHp, player.hp + ev.amount);
          break;

        default:
          console.warn("Unknown event:", ev);
      }
    }
  },
};

// ═══════════════════════════════════════════════════════════════
// 4. IMAGE AI MANAGER
//    Generates and composites character/item images
// ═══════════════════════════════════════════════════════════════

class ImageAI {
  /**
   * @param {Object} config
   *   backend   "pollinations" | "mock"
   *   width     number (default 512)
   *   height    number (default 512)
   */
  constructor(config = {}) {
    this.backend = config.backend ?? "pollinations";
    this.width   = config.width   ?? 512;
    this.height  = config.height  ?? 512;
    this._cache  = new Map(); // prompt → imageUrl
  }

  /**
   * Generate a base character image from appearance data.
   * @param {Object} character - Character instance
   * @returns {Promise<string>} image URL
   */
  async generateCharacterImage(character) {
    const prompt = this._characterPrompt(character);
    return this._generate(prompt, `char_${character.id}`);
  }

  /**
   * Generate an item image.
   * @param {Object} item - item object
   * @returns {Promise<string>} image URL
   */
  async generateItemImage(item) {
    const prompt = this._itemPrompt(item);
    return this._generate(prompt, `item_${item.id}`);
  }

  /**
   * Compose a character image with all equipped items layered on top.
   * Uses canvas compositing: base character + overlay item images.
   * @param {Object} character - Character instance with baseImageUrl set
   * @returns {Promise<string>} data URL of composite
   */
  async generateCompositeImage(character) {
    if (typeof document === "undefined") return character.baseImageUrl;

    const equippedImages = Object.values(character.equipment)
      .filter(item => item?.imageUrl)
      .map(item => item.imageUrl);

    if (equippedImages.length === 0) return character.baseImageUrl;

    const canvas  = document.createElement("canvas");
    canvas.width  = this.width;
    canvas.height = this.height;
    const ctx = canvas.getContext("2d");

    // Draw base character
    if (character.baseImageUrl) {
      await this._drawImage(ctx, character.baseImageUrl, 0, 0, this.width, this.height);
    }

    // Layer equipped items (simplified: draw at defined anchor points)
    // In a real implementation the AI would handle positioning via prompt
    for (const imgUrl of equippedImages) {
      await this._drawImage(ctx, imgUrl, 0, 0, this.width, this.height, 0.7);
    }

    return canvas.toDataURL("image/png");
  }

  /**
   * Generate a scene/location image.
   */
  async generateSceneImage(tile, worldContext = "") {
    const tileType = tile.type || "wilderness";
    const desc     = tile.description || "an unknown location in a dark fantasy world";
    const prompt   = `Dark fantasy RPG scene art. ${desc}. ${worldContext}. Environment type: ${tileType}. `
                   + `Moody lighting. Detailed background. Painterly style. No characters. No text.`;
    return this._generate(prompt, `scene_${tile.x}_${tile.y}`);
  }

  // ── Internal helpers ───────────────────────────────────────

  _characterPrompt(char) {
    const app = char.appearance || {};
    return [
      "Dark fantasy RPG character portrait, full body.",
      char.race  ? `Race: ${char.race}.`           : "",
      char.sex   ? `Sex: ${char.sex}.`             : "",
      app.bodyType        ? app.bodyType + " build." : "",
      app.skinTone        ? app.skinTone + " skin."  : "",
      app.hairStyle       ? app.hairStyle + " hair."  : "",
      app.eyeColor        ? app.eyeColor + " eyes."   : "",
      app.clothingStyle   ? app.clothingStyle + "."    : "",
      app.marks           ? app.marks + "."            : "",
      "Painterly style. Dramatic lighting. Detailed. No text. No UI.",
    ].filter(Boolean).join(" ");
  }

  _itemPrompt(item) {
    return [
      `Dark fantasy RPG item illustration.`,
      `Name: ${item.name}.`,
      item.description ? item.description : "",
      `Type: ${item.type}.`,
      `Rarity: ${item.rarityData?.name || "Common"}.`,
      `Isolated on dark background. High detail. Painterly. No text.`,
    ].filter(Boolean).join(" ");
  }

  async _generate(prompt, cacheKey) {
    if (this._cache.has(cacheKey)) return this._cache.get(cacheKey);

    let url;
    if (this.backend === "pollinations") {
      url = await this._pollinations(prompt);
    } else {
      url = this._mockImage(prompt);
    }

    this._cache.set(cacheKey, url);
    return url;
  }

  async _pollinations(prompt) {
    // Pollinations.ai — free, no auth required
    const encoded = encodeURIComponent(prompt.slice(0, 500));
    const url = `https://image.pollinations.ai/prompt/${encoded}?width=${this.width}&height=${this.height}&nologo=true&model=flux`;
    // Return the URL directly; browser will load it as an <img> src
    return url;
  }

  _mockImage(prompt) {
    // Return a placeholder SVG data URL for dev/testing
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.width}" height="${this.height}">
      <rect width="100%" height="100%" fill="#1a1408"/>
      <text x="50%" y="45%" font-family="serif" font-size="14" fill="#c9a84c" text-anchor="middle">🌅</text>
      <text x="50%" y="55%" font-family="serif" font-size="10" fill="#7a6030" text-anchor="middle">AI Image</text>
    </svg>`;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  }

  async _drawImage(ctx, src, x, y, w, h, alpha = 1) {
    return new Promise((resolve) => {
      const img   = new Image();
      img.crossOrigin = "anonymous";
      img.onload  = () => {
        ctx.globalAlpha = alpha;
        ctx.drawImage(img, x, y, w, h);
        ctx.globalAlpha = 1;
        resolve();
      };
      img.onerror = () => resolve(); // skip on fail
      img.src = src;
    });
  }
}

// ═══════════════════════════════════════════════════════════════
// 5. CONVERSATION MANAGER
//    Maintains chat history per session, manages context window
// ═══════════════════════════════════════════════════════════════

class ConversationManager {
  constructor({ maxHistory = 20 } = {}) {
    this.maxHistory = maxHistory;
    this.history    = [];     // { role, content }[]
  }

  addUserMessage(content) {
    this.history.push({ role: "user", content });
    this._trim();
  }

  addAssistantMessage(content) {
    this.history.push({ role: "assistant", content });
    this._trim();
  }

  /** Return recent history for API call (excludes system prompt) */
  getContext() {
    return [...this.history];
  }

  clear() { this.history = []; }

  _trim() {
    if (this.history.length > this.maxHistory * 2) {
      // Keep first exchange for context anchor, trim middle
      const head = this.history.slice(0, 2);
      const tail = this.history.slice(-(this.maxHistory * 2 - 2));
      this.history = [...head, ...tail];
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// 6. DAWN AI  — Top-level orchestrator
// ═══════════════════════════════════════════════════════════════

class DawnAI {
  constructor(gameState, config = {}) {
    this.gameState    = gameState;
    this.narrative    = new NarrativeAI(config.narrative   || {});
    this.imageAI      = new ImageAI(config.image           || {});
    this.conversation = new ConversationManager(config.conversation || {});

    // Expose sub-components
    this.contextBuilder = ContextBuilder;
    this.outputParser   = OutputParser;

    // Event callbacks set by UI
    this.onNarrative  = null;  // fn(text)
    this.onImageReady = null;  // fn(entityId, imageUrl, type)
    this.onEvent      = null;  // fn(event)
    this.onMessage    = null;  // fn(systemMessage)
    this.onLoading    = null;  // fn(bool)
  }

  // ── Initialise ─────────────────────────────────────────────

  async init() {
    this.narrative.on("progress", (r) => {
      this.onMessage?.(`Loading AI model: ${(r.progress * 100).toFixed(0)}%`);
    });
    this.narrative.on("ready", (r) => {
      this.onMessage?.(`AI ready (${r.backend}).`);
    });
    await this.narrative.loadModel();
  }

  // ── Player command ─────────────────────────────────────────

  /**
   * Main entry: player types something, AI responds.
   * @param {string} input
   * @returns {Promise<{ text: string, events: Array }>}
   */
  async handlePlayerInput(input) {
    this.onLoading?.(true);
    try {
      const systemPrompt = ContextBuilder.buildSystemPrompt(this.gameState);
      this.conversation.addUserMessage(input);

      const raw = await this.narrative.generate(
        systemPrompt,
        this.conversation.getContext().slice(0, -1), // exclude the one we just added
        input,
      );

      const { cleanText, events } = OutputParser.parse(raw);
      this.conversation.addAssistantMessage(cleanText);

      // Apply game events
      OutputParser.applyEvents(events, this.gameState, {
        onCombat:     (ev) => this.onEvent?.({ type: "combatStart",   data: ev }),
        onLearnSkill: (ev) => this.onEvent?.({ type: "skillLearned",  data: ev }),
        onLoot:       (ev) => this.onEvent?.({ type: "itemLooted",    data: ev }),
        onTame:       (ev) => this.onEvent?.({ type: "petTamed",      data: ev }),
        onNpcMet:     (ev) => this.onEvent?.({ type: "npcMet",        data: ev }),
        onMessage:    (msg) => this.onMessage?.(msg),
      });

      this.onNarrative?.(cleanText);
      this.onLoading?.(false);
      return { text: cleanText, events };
    } catch (err) {
      this.onLoading?.(false);
      const fallback = "The world shudders... (AI error: " + err.message + ")";
      this.onNarrative?.(fallback);
      return { text: fallback, events: [] };
    }
  }

  // ── Movement ───────────────────────────────────────────────

  async handleMovement(direction) {
    const moveResult = this.gameState.move(direction);
    this.onLoading?.(true);

    const systemPrompt = ContextBuilder.buildSystemPrompt(this.gameState);
    const tile         = moveResult.tile;

    // If tile already has a description, use it directly
    if (tile?.description) {
      const text = tile.description;
      this.onNarrative?.(text);

      // Generate scene image if not cached
      if (!tile.imageUrl) {
        this.imageAI.generateSceneImage(tile).then(url => {
          tile.imageUrl = url;
          this.onImageReady?.(null, url, "scene");
        });
      } else {
        this.onImageReady?.(null, tile.imageUrl, "scene");
      }
      this.onLoading?.(false);
      return { text, events: [] };
    }

    // Ask AI to describe new tile
    const eventPrompt = ContextBuilder.buildEventPrompt("movement", {
      direction,
      x:         moveResult.newX,
      y:         moveResult.newY,
      tileType:  tile?.type || "wilderness",
      spawnType: moveResult.spawn,
    });

    const raw = await this.narrative.generate(systemPrompt, this.conversation.getContext(), eventPrompt);
    const { cleanText, events } = OutputParser.parse(raw);

    this.conversation.addAssistantMessage(cleanText);
    OutputParser.applyEvents(events, this.gameState, {
      onMessage: (msg) => this.onMessage?.(msg),
    });

    this.onNarrative?.(cleanText);

    // Generate scene image
    if (tile && !tile.imageUrl) {
      this.imageAI.generateSceneImage(tile).then(url => {
        tile.imageUrl = url;
        this.onImageReady?.(null, url, "scene");
      });
    }

    this.onLoading?.(false);
    return { text: cleanText, events };
  }

  // ── Skill check narration ──────────────────────────────────

  async narrateSkillCheck(statKey, difficulty, diceResult) {
    const narrativeWeight = _E.DiceEngine?.narrativeWeight?.(diceResult) || (diceResult.success ? "normal" : "close_fail");
    const prompt = ContextBuilder.buildEventPrompt("skillCheck", {
      statKey,
      statValue: this.gameState.party?.player?.stats[statKey],
      ...diceResult,
      narrativeWeight,
    });
    const systemPrompt = ContextBuilder.buildSystemPrompt(this.gameState);
    const raw = await this.narrative.generate(systemPrompt, this.conversation.getContext(), prompt);
    const { cleanText } = OutputParser.parse(raw);
    this.onNarrative?.(cleanText);
    return cleanText;
  }

  // ── Character image generation ────────────────────────────

  async generateCharacterImage(character) {
    const url = await this.imageAI.generateCharacterImage(character);
    character.baseImageUrl = url;
    this.onImageReady?.(character.id, url, "character_base");
    return url;
  }

  async generateItemImage(item) {
    const url = await this.imageAI.generateItemImage(item);
    item.imageUrl = url;
    this.onImageReady?.(item.id, url, "item");
    return url;
  }

  async refreshCompositeImage(character) {
    const url = await this.imageAI.generateCompositeImage(character);
    character.compositeImageUrl = url;
    this.onImageReady?.(character.id, url, "character_composite");
    return url;
  }

  // ── Item hover description ─────────────────────────────────

  async getItemDescription(item) {
    const prompt = ContextBuilder.buildEventPrompt("itemHover", {
      name:  item.name,
      type:  item.type,
      rarity: item.rarityData?.name || "Common",
      stats: item.stats,
    });
    const systemPrompt = ContextBuilder.buildSystemPrompt(this.gameState);
    const raw = await this.narrative.generate(systemPrompt, [], prompt);
    const { cleanText } = OutputParser.parse(raw);
    return cleanText;
  }
}

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

const DawnAILayer = {
  NarrativeAI,
  ImageAI,
  ContextBuilder,
  OutputParser,
  ConversationManager,
  DawnAI,
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = DawnAILayer;
} else {
  window.DawnAILayer = DawnAILayer;
}
