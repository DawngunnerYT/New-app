/**
 * DAWN AI RPG — Game Engine
 * Core mathematical and state engine.
 * All game logic lives here. No UI dependencies.
 */

"use strict";

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

const ENGINE_VERSION = "1.0.0";

const DIFFICULTY = {
  TRIVIAL:  0.25,
  EASY:     0.5,
  NORMAL:   1.0,
  HARD:     1.5,
  EXTREME:  2.0,
};

const RARITY = {
  1:  { name: "Common",        color: "#9e9e9e", dropWeight: 500 },
  2:  { name: "Uncommon",      color: "#4caf50", dropWeight: 200 },
  3:  { name: "Rare",          color: "#2196f3", dropWeight:  80 },
  4:  { name: "Epic",          color: "#9c27b0", dropWeight:  30 },
  5:  { name: "Legendary",     color: "#ff9800", dropWeight:  10 },
  6:  { name: "Mythic",        color: "#f44336", dropWeight:   4 },
  7:  { name: "Arcane",        color: "#e91e63", dropWeight:   2 },
  8:  { name: "Divine",        color: "#00bcd4", dropWeight:   1 },
  9:  { name: "Primordial",    color: "#ff5722", dropWeight:   0.5 },
  10: { name: "Mythic/Unique", color: "#ffd700", dropWeight:   0.1 },
};

// Sub-stat counts by rarity
const RARITY_SUBSTATS = { 1:1, 2:2, 3:3, 4:4, 5:5, 6:6, 7:7, 8:8, 9:9, 10:10 };

const SPAWN_RATES = {
  WILDERNESS: { passive: 0.80, neutral: 0.15, hostile_creature: 0.04, hostile_humanoid: 0.01 },
  PROTECTION: { passive: 0.00, neutral: 0.99, hostile_creature: 0.00, hostile_humanoid: 0.01 },
  DUNGEON:    { passive: 0.00, neutral: 0.00, hostile_creature: 0.80, hostile_humanoid: 0.10, exotic: 0.10 },
  TOWN:       { passive: 1.00, neutral: 0.00, hostile_creature: 0.00, hostile_humanoid: 0.00 },
};

const GRID_TYPES = {
  WILDERNESS: "wilderness",
  TOWN:       "town",
  DUNGEON:    "dungeon",
  PROTECTION: "protection",
  DUNGEON_INTERIOR: "dungeon_interior",
};

const CURRENCY = {
  COPPER:   1,
  SILVER:   10,
  GOLD:     100,
  PLATINUM: 1000,
};

const MAX_PARTY_SIZE   = 4;
const MAX_LEVEL        = 200;
const BASE_CARRY_LBS   = 10;
const CARRY_PER_STR10  = 5;
const BASE_STAT        = 5;
const STAT_POINTS_START = 10;
const SUBSTAT_BASE     = 1;    // 1% per level
const DUNGEON_SPAWN_RATE = 0.01; // 1-in-100 chance per wilderness tile

// ═══════════════════════════════════════════════════════════════
// UTILITY
// ═══════════════════════════════════════════════════════════════

const Util = {
  /** Integer random [min, max] inclusive */
  randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  /** Float random [0, 1) */
  rand() { return Math.random(); },

  /** Clamp value between lo and hi */
  clamp(val, lo, hi) { return Math.max(lo, Math.min(hi, val)); },

  /** Generate a unique ID */
  uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  },

  /** Weighted random pick from [{item, weight}] */
  weightedPick(entries) {
    const total = entries.reduce((s, e) => s + e.weight, 0);
    let r = Math.random() * total;
    for (const e of entries) {
      r -= e.weight;
      if (r <= 0) return e.item;
    }
    return entries[entries.length - 1].item;
  },

  /** Deep clone */
  clone(obj) { return JSON.parse(JSON.stringify(obj)); },

  /** Format copper amount to readable currency string */
  formatCurrency(copper) {
    const plat   = Math.floor(copper / 1000);
    const gold   = Math.floor((copper % 1000) / 100);
    const silver = Math.floor((copper % 100) / 10);
    const cop    = copper % 10;
    const parts  = [];
    if (plat)   parts.push(`${plat}pt`);
    if (gold)   parts.push(`${gold}g`);
    if (silver) parts.push(`${silver}s`);
    if (cop || parts.length === 0) parts.push(`${cop}c`);
    return parts.join(" ");
  },
};

// ═══════════════════════════════════════════════════════════════
// DICE ENGINE
// ═══════════════════════════════════════════════════════════════

const DiceEngine = {
  /**
   * Perform a skill check.
   * @param {number} stat       - Raw stat value (e.g. 50)
   * @param {number} level      - Player level
   * @param {number} difficulty - DIFFICULTY constant (0.25 – 2.0)
   * @returns {{ roll, target, maxRoll, success, margin, critSuccess, critFail }}
   */
  rollCheck(stat, level, difficulty = DIFFICULTY.NORMAL) {
    const maxRoll  = level * 10;
    const rawT     = (stat * 10) / difficulty;
    const capT     = Math.floor(maxRoll * 0.95); // 95% rule
    const target   = Math.min(rawT, capT);
    const roll     = Util.randInt(0, maxRoll);
    const success  = roll < target;

    // Critical: top/bottom 5% of range relative to target
    const critSuccess = success && roll < target * 0.05;
    const critFail    = !success && roll > maxRoll * 0.95;
    const margin      = success ? target - roll : roll - target;

    return { roll, target: Math.round(target), maxRoll, success, margin, critSuccess, critFail };
  },

  /**
   * Roll a generic d-sided die.
   */
  roll(sides) { return Util.randInt(1, sides); },

  /**
   * Roll multiple dice, return array of results.
   */
  rollMultiple(count, sides) {
    return Array.from({ length: count }, () => this.roll(sides));
  },

  /**
   * Determine narrative weight from margin.
   * @returns {"legendary"|"strong"|"normal"|"narrow"|"critical_fail"|"close_fail"}
   */
  narrativeWeight(result) {
    if (result.critSuccess) return "legendary";
    if (result.critFail)    return "critical_fail";
    if (!result.success) {
      return result.margin > result.maxRoll * 0.2 ? "close_fail" : "critical_fail";
    }
    const pct = result.margin / result.target;
    if (pct > 0.6) return "legendary";
    if (pct > 0.3) return "strong";
    if (pct > 0.1) return "normal";
    return "narrow";
  },
};

// ═══════════════════════════════════════════════════════════════
// STAT ENGINE
// ═══════════════════════════════════════════════════════════════

/**
 * A character's raw main stats.
 * All start at BASE_STAT (5), scaled by allocation.
 */
function createBaseStats(overrides = {}) {
  return {
    luck:         BASE_STAT,
    agility:      BASE_STAT,
    charisma:     BASE_STAT,
    wisdom:       BASE_STAT,
    perception:   BASE_STAT,
    intelligence: BASE_STAT,
    strength:     BASE_STAT,
    constitution: BASE_STAT,
    ...overrides,
  };
}

const StatEngine = {
  /**
   * Compute flat resource buffs from a full stat object.
   * Returns { hp, stamina, magic } BONUS pools (not base).
   */
  computeResourceBuffs(stats) {
    const { luck, agility, charisma, wisdom, perception, intelligence, strength, constitution } = stats;

    const hpBonus = (
      Math.floor(luck         / 10) * 100 +
      Math.floor(agility      / 10) *  50 +
      Math.floor(charisma     / 10) * 200 +
      Math.floor(perception   / 10) *  50 +
      Math.floor(intelligence / 10) *  50 +
      Math.floor(strength     / 10) * 200 +
      Math.floor(constitution / 10) * 200
    );

    const staminaBonus = (
      Math.floor(luck         / 10) * 100 +
      Math.floor(agility      / 10) * 200 +
      Math.floor(charisma     / 10) *  50 +
      Math.floor(perception   / 10) * 200 +
      Math.floor(intelligence / 10) *  50 +
      Math.floor(strength     / 10) *  50 +
      Math.floor(constitution / 10) *  50
    );

    const magicBonus = (
      Math.floor(luck         / 10) * 100 +
      Math.floor(agility      / 10) *  50 +
      Math.floor(charisma     / 10) *  50 +
      Math.floor(perception   / 10) *  50 +
      Math.floor(intelligence / 10) * 200 +
      Math.floor(strength     / 10) *  50 +
      Math.floor(constitution / 10) *  50
    );

    return { hpBonus, staminaBonus, magicBonus };
  },

  /**
   * Compute total max resource pools for a character.
   * @param {Object} stats - main stats
   * @param {number} level
   * @returns {{ maxHp, maxStamina, maxMagic }}
   */
  computeMaxPools(stats, level) {
    const buffs  = this.computeResourceBuffs(stats);
    const lvlMul = 1 + (level - 1) * 0.1; // 10% per level above 1

    const maxHp      = Math.round((500 + buffs.hpBonus)      * lvlMul);
    const maxStamina = Math.round((500 + buffs.staminaBonus) * lvlMul);
    const maxMagic   = Math.round((500 + buffs.magicBonus)   * lvlMul);

    return { maxHp, maxStamina, maxMagic };
  },

  /**
   * Compute carry capacity in lbs.
   */
  computeCarry(stats, mountBonus = 0) {
    return BASE_CARRY_LBS + Math.floor(stats.strength / 10) * CARRY_PER_STR10 + mountBonus;
  },

  /**
   * Compute sub-stat percentage for a stat at a given level.
   * Sub-stats start at SUBSTAT_BASE % and scale by 1% per level.
   */
  subStatPercent(level) {
    return SUBSTAT_BASE + (level - 1);
  },

  /**
   * Get all sub-stats for a character's stat block.
   * Returns a flat map of sub-stat name → value.
   */
  computeSubStats(stats, level) {
    const pct = this.subStatPercent(level);
    return {
      // Luck
      chance_x:              pct * stats.luck / 100,
      lucky_crit_x:          pct * stats.luck / 100,
      magic_find_plus:       pct * stats.luck / 100,
      gold_find_plus:        pct * stats.luck / 100,
      good_encounter_plus:   pct * stats.luck / 100,
      lucky_dodge_x:         pct * stats.luck / 100,
      // Agility
      stamina_x:             pct * stats.agility / 100,
      travel_speed_plus:     pct * stats.agility / 100,
      attack_speed_x:        pct * stats.agility / 100,
      dodge_x:               pct * stats.agility / 100,
      stealth_x:             pct * (stats.agility + stats.perception) / 200,
      escape_plus:           pct * stats.agility / 100,
      sleight_x:             pct * stats.agility / 100,
      // Charisma
      persuade_plus:         pct * stats.charisma / 100,
      problem_solving_plus:  pct * stats.charisma / 100,
      sell_earnings_x:       pct * stats.charisma / 100,
      buy_cost_minus:        pct * stats.charisma / 100,
      barter_plus:           pct * (stats.charisma + stats.wisdom) / 200,
      taming_x:              pct * stats.charisma / 100,
      // Wisdom
      magic_x:               pct * stats.wisdom / 100,
      spell_dmg_x:           pct * stats.wisdom / 100,
      melee_dmg_x:           pct * stats.wisdom / 100,
      skill_x:               pct * stats.wisdom / 100,
      // Perception
      encounter_minus:       pct * stats.perception / 100,
      awareness_x:           pct * stats.perception / 100,
      crit_plus:             pct * stats.perception / 100,
      crit_dmg_x:            pct * stats.perception / 100,
      lockpick_x:            pct * stats.perception / 100,
      see_dist_x:            pct * stats.perception / 100,
      enemy_detect_x:        pct * stats.perception / 100,
      trap_detect_x:         pct * stats.perception / 100,
      // Intelligence
      magic_res_plus:        pct * stats.intelligence / 100,
      spell_learn_plus:      pct * stats.intelligence / 100,
      spell_strength_x:      pct * stats.intelligence / 100,
      enchant_x:             pct * stats.intelligence / 100,
      alchemy_x:             pct * stats.intelligence / 100,
      // Strength
      health_x:              pct * (stats.strength + stats.constitution) / 200,
      attack_dmg_x:          pct * stats.strength / 100,
      craft_speed_x:         pct * stats.strength / 100,
      // Constitution
      bless_chance_x:        pct * stats.constitution / 100,
      bless_strength_x:      pct * stats.constitution / 100,
      heal_strength_x:       pct * stats.constitution / 100,
    };
  },
};

// ═══════════════════════════════════════════════════════════════
// DAMAGE ENGINE  (The R Formula)
// ═══════════════════════════════════════════════════════════════

const DamageEngine = {
  /**
   * Calculate final real damage.
   * @param {Object} p
   *   costPct       - fraction of resource spent (0.0–1.0)
   *   resourcePool  - max pool value (HP/Stam/Magic)
   *   baseDamage    - flat base (50 for basic attack)
   *   weaponDamage  - from equipped weapon stat
   *   additivePools - array of flat additive bonuses from sub-stats/enchants
   *   multipliers   - array of %x multipliers (as decimals, e.g. 1.15 = +15%)
   *   critResult    - boolean
   *   critDmgMul    - crit damage multiplier (default 2.0)
   */
  compute({ costPct = 0, resourcePool = 0, baseDamage = 0, weaponDamage = 0,
            additivePools = [], multipliers = [], critResult = false, critDmgMul = 2.0 }) {
    // Primary result r
    const r = (costPct * resourcePool) + baseDamage + weaponDamage;

    // Sum all additive pools
    const sumAdd = additivePools.reduce((s, v) => s + v, 0);

    // Pre-multiplier total
    const preMul = r + sumAdd;

    // Apply all multipliers sequentially
    let R = preMul;
    for (const m of multipliers) { R *= m; }

    // Apply crit
    if (critResult) R *= critDmgMul;

    return {
      r: Math.round(r),
      sumAdd: Math.round(sumAdd),
      preMul: Math.round(preMul),
      finalDamage: Math.max(0, Math.round(R)),
      isCrit: critResult,
    };
  },

  /**
   * Basic Attack (0 cost, 50 base, pulls from Stamina).
   */
  basicAttack(weaponDmg, subStats, staminaPool, level) {
    const addPools = [
      staminaPool * (subStats.attack_dmg_x || 0),
    ];
    const muls = [
      1 + (subStats.melee_dmg_x  || 0),
      1 + (subStats.attack_dmg_x || 0),
    ];
    const critRoll = Math.random() < (subStats.crit_plus || 0);
    return this.compute({
      costPct: 0,
      resourcePool: staminaPool,
      baseDamage: 50,
      weaponDamage: weaponDmg,
      additivePools: addPools,
      multipliers: muls,
      critResult: critRoll,
      critDmgMul: 1.5 + (subStats.crit_dmg_x || 0),
    });
  },

  /**
   * Spell attack.
   */
  spellAttack({ costPct, magicPool, baseSpellDmg, subStats }) {
    const addPools = [
      magicPool * (subStats.spell_dmg_x    || 0),
      magicPool * (subStats.spell_strength_x || 0),
    ];
    const muls = [
      1 + (subStats.spell_dmg_x    || 0),
      1 + (subStats.spell_strength_x || 0),
      1 + (subStats.magic_x         || 0),
    ];
    const critRoll = Math.random() < (subStats.crit_plus || 0);
    return this.compute({
      costPct,
      resourcePool: magicPool,
      baseDamage: baseSpellDmg,
      weaponDamage: 0,
      additivePools: addPools,
      multipliers: muls,
      critResult: critRoll,
      critDmgMul: 2.0 + (subStats.crit_dmg_x || 0),
    });
  },

  /**
   * Apply damage to a character's current HP.
   * Returns updated hp value.
   */
  applyDamage(currentHp, damage) {
    return Math.max(0, currentHp - damage);
  },
};

// ═══════════════════════════════════════════════════════════════
// ITEM ENGINE
// ═══════════════════════════════════════════════════════════════

const ItemEngine = {
  /**
   * Roll rarity from a weighted pool, optionally biased by Magic Find %.
   * @param {number} magicFindBonus - flat % bonus to rare+ weight
   */
  rollRarity(magicFindBonus = 0) {
    const entries = Object.entries(RARITY).map(([tier, data]) => ({
      item: parseInt(tier),
      weight: data.dropWeight * (parseInt(tier) >= 3 ? (1 + magicFindBonus / 100) : 1),
    }));
    return Util.weightedPick(entries);
  },

  /**
   * Roll a single sub-stat value in range [0, 200].
   */
  rollSubStatValue() {
    return Util.randInt(0, 200);
  },

  /**
   * Does this item roll an enchant slot?
   * ~5% base chance, scales slightly with rarity.
   */
  rollEnchantSlot(rarity) {
    return Math.random() < (0.03 + rarity * 0.01);
  },

  /**
   * Apply durability decay to an item.
   * @param {Object} item   - item object with .durability
   * @param {string} material - "metal"|"wood"|"leather"|"cloth"
   * @returns {Object} updated item
   */
  applyDurabilityDecay(item, material = "metal") {
    if (!item.durability || item.durability.max === 1) return item; // single-use or no durability
    const decayRates = { metal: 1, leather: 1.5, wood: 2, cloth: 2.5 };
    const decay = decayRates[material] || 1;
    item.durability.current = Math.max(0, item.durability.current - decay);
    if (item.durability.current <= 0) item.broken = true;
    return item;
  },

  /**
   * Determine if an item is a consumable based on its type tag.
   */
  isConsumable(type) {
    return ["potion", "food", "scroll", "material"].includes(type);
  },

  /**
   * Create a new item object.
   */
  createItem({ name, type, icon, description, rarity, stats = {}, weaponDmg = 0, weightLbs = 0.5, enchantSlot = false, gemSlot = null }) {
    const isConsumable = this.isConsumable(type);
    return {
      id:          Util.uid(),
      name,
      type,
      icon,
      description,
      rarity,
      rarityData:  RARITY[rarity],
      stats,
      weaponDmg,
      weightLbs,
      enchantSlot,
      gemSlot,
      count:       1,
      durability:  isConsumable ? { current: 1, max: 1 } : { current: 100, max: 100 },
      broken:      false,
      imageUrl:    null, // set by AI image engine
    };
  },

  /**
   * Slot a gem into an item.
   * Consumes the gem, updates item stats/image.
   */
  slotGem(item, gem) {
    if (!item.enchantSlot) return { success: false, reason: "No enchant slot on this item." };
    if (item.gemSlot) return { success: false, reason: "Slot already filled." };
    item.gemSlot = gem;
    // Apply gem's stat bonus
    if (gem.statKey && gem.statValue) {
      item.stats[gem.statKey] = (item.stats[gem.statKey] || 0) + gem.statValue;
    }
    item.imageUrl = null; // trigger re-generation
    return { success: true };
  },
};

// ═══════════════════════════════════════════════════════════════
// INVENTORY ENGINE
// ═══════════════════════════════════════════════════════════════

class Inventory {
  constructor(maxWeightLbs = BASE_CARRY_LBS) {
    this.items = [];
    this.maxWeightLbs = maxWeightLbs;
    this.copper = 0; // all currency stored in copper
  }

  get currentWeight() {
    return this.items.reduce((s, i) => s + (i.weightLbs * (i.count || 1)), 0);
  }

  get remainingWeight() {
    return Math.max(0, this.maxWeightLbs - this.currentWeight);
  }

  canAdd(item) {
    return this.currentWeight + item.weightLbs <= this.maxWeightLbs;
  }

  addItem(item) {
    if (!this.canAdd(item)) return { success: false, reason: "Inventory too heavy." };
    // Stack consumables
    if (ItemEngine.isConsumable(item.type)) {
      const existing = this.items.find(i => i.name === item.name);
      if (existing) { existing.count = (existing.count || 1) + 1; return { success: true }; }
    }
    this.items.push(item);
    return { success: true };
  }

  removeItem(itemId, count = 1) {
    const idx = this.items.findIndex(i => i.id === itemId);
    if (idx === -1) return { success: false };
    const item = this.items[idx];
    if (item.count && item.count > count) {
      item.count -= count;
    } else {
      this.items.splice(idx, 1);
    }
    return { success: true, item };
  }

  addCurrency(copper) { this.copper += copper; }
  spendCurrency(copper) {
    if (this.copper < copper) return { success: false, reason: "Insufficient funds." };
    this.copper -= copper;
    return { success: true };
  }

  get currencyDisplay() { return Util.formatCurrency(this.copper); }

  toJSON() {
    return { items: this.items, maxWeightLbs: this.maxWeightLbs, copper: this.copper };
  }

  static fromJSON(data) {
    const inv = new Inventory(data.maxWeightLbs);
    inv.items = data.items;
    inv.copper = data.copper;
    return inv;
  }
}

// ═══════════════════════════════════════════════════════════════
// CHARACTER ENGINE
// ═══════════════════════════════════════════════════════════════

class Character {
  constructor({
    id = Util.uid(),
    name,
    sex,
    race,
    age,
    origin,
    occupation,
    background,
    personality,
    fears,
    goals,
    morality,
    // Appearance
    bodyType, height, skinTone, hairStyle, eyeColor,
    marks, facialFeatures, clothingStyle, voiceStyle, accessories, aura,
    // Stats
    stats = createBaseStats(),
    level = 1,
    xp = 0,
    isPet = false,
    isMount = false,
    species = null,
    petBond = null,
  } = {}) {
    this.id = id;
    this.name = name;
    this.sex = sex;
    this.race = race;
    this.age = age;
    this.origin = origin;
    this.occupation = occupation;
    this.background = background;
    this.personality = personality;
    this.fears = fears;
    this.goals = goals;
    this.morality = morality;

    // Appearance block (used for AI image generation)
    this.appearance = { bodyType, height, skinTone, hairStyle, eyeColor, marks, facialFeatures, clothingStyle, voiceStyle, accessories, aura };

    this.stats = stats;
    this.level = level;
    this.xp = xp;

    // Pet/Mount flags
    this.isPet = isPet;
    this.isMount = isMount;
    this.species = species;
    this.petBond = petBond;

    // Equipment slots
    this.equipment = {
      head: null, chest: null, hands: null, feet: null,
      mainHand: null, offHand: null,
      ring1: null, ring2: null, amulet: null,
      trinket: null,
    };

    this.skills = []; // learned spells/abilities

    // Current resource pools (computed on init)
    const pools = StatEngine.computeMaxPools(this.stats, this.level);
    this.maxHp      = pools.maxHp;
    this.maxStamina = pools.maxStamina;
    this.maxMagic   = pools.maxMagic;
    this.hp         = this.maxHp;
    this.stamina    = this.maxStamina;
    this.magic      = this.maxMagic;

    // Base image URL (set by AI)
    this.baseImageUrl = null;
    this.compositeImageUrl = null; // updated on equip
  }

  get subStats() {
    return StatEngine.computeSubStats(this.stats, this.level);
  }

  get carryCapacity() {
    return StatEngine.computeCarry(this.stats);
  }

  /** Recalculate max pools (call after stat changes or level up) */
  recalcPools() {
    const pools = StatEngine.computeMaxPools(this.stats, this.level);
    const hpPct  = this.hp      / this.maxHp;
    const stPct  = this.stamina / this.maxStamina;
    const mpPct  = this.magic   / this.maxMagic;
    this.maxHp      = pools.maxHp;
    this.maxStamina = pools.maxStamina;
    this.maxMagic   = pools.maxMagic;
    this.hp         = Math.round(this.maxHp      * hpPct);
    this.stamina    = Math.round(this.maxStamina * stPct);
    this.magic      = Math.round(this.maxMagic   * mpPct);
  }

  /** Level up and grant stat points */
  levelUp() {
    if (this.level >= MAX_LEVEL) return { success: false, reason: "Already at max level." };
    this.level++;
    this.xp = 0;
    this.recalcPools();
    // Full restore on level up
    this.hp      = this.maxHp;
    this.stamina = this.maxStamina;
    this.magic   = this.maxMagic;
    return { success: true, newLevel: this.level };
  }

  equip(slot, item) {
    if (!(slot in this.equipment)) return { success: false, reason: "Invalid slot." };
    if (item && item.broken) return { success: false, reason: "Cannot equip a broken item." };
    const old = this.equipment[slot];
    this.equipment[slot] = item || null;
    this.compositeImageUrl = null; // trigger re-render
    return { success: true, unequipped: old };
  }

  unequip(slot) {
    return this.equip(slot, null);
  }

  /** Check if this character is alive */
  get isAlive() { return this.hp > 0; }

  /** Computed weapon damage from equipped main hand */
  get weaponDamage() {
    return this.equipment.mainHand?.weaponDmg || 0;
  }

  /** Computed weapon material for durability */
  get weaponMaterial() {
    const w = this.equipment.mainHand;
    if (!w) return "metal";
    if (w.description?.toLowerCase().includes("wood")) return "wood";
    if (w.description?.toLowerCase().includes("leather")) return "leather";
    return "metal";
  }

  toJSON() {
    return {
      id: this.id, name: this.name, sex: this.sex, race: this.race, age: this.age,
      origin: this.origin, occupation: this.occupation, background: this.background,
      personality: this.personality, fears: this.fears, goals: this.goals, morality: this.morality,
      appearance: this.appearance, stats: this.stats, level: this.level, xp: this.xp,
      equipment: this.equipment, skills: this.skills,
      hp: this.hp, stamina: this.stamina, magic: this.magic,
      maxHp: this.maxHp, maxStamina: this.maxStamina, maxMagic: this.maxMagic,
      isPet: this.isPet, isMount: this.isMount, species: this.species, petBond: this.petBond,
      baseImageUrl: this.baseImageUrl, compositeImageUrl: this.compositeImageUrl,
    };
  }

  static fromJSON(data) {
    const c = new Character(data);
    c.equipment = data.equipment;
    c.skills = data.skills;
    c.hp = data.hp; c.stamina = data.stamina; c.magic = data.magic;
    c.maxHp = data.maxHp; c.maxStamina = data.maxStamina; c.maxMagic = data.maxMagic;
    c.baseImageUrl = data.baseImageUrl;
    c.compositeImageUrl = data.compositeImageUrl;
    return c;
  }
}

// ═══════════════════════════════════════════════════════════════
// PARTY ENGINE
// ═══════════════════════════════════════════════════════════════

class Party {
  constructor() {
    this.members     = [];   // up to MAX_PARTY_SIZE Characters
    this.pets        = [];   // pets/mounts per member (not in party slots)
    this.inventory   = new Inventory();
    this.mountBonus  = 0;    // extra carry from mounts with saddlebags
  }

  get player() { return this.members[0] || null; }

  get totalCarryCapacity() {
    const base = this.members.reduce((s, m) => s + m.carryCapacity, 0);
    return base + this.mountBonus;
  }

  addMember(character) {
    if (this.members.length >= MAX_PARTY_SIZE) return { success: false, reason: "Party full." };
    this.members.push(character);
    this.inventory.maxWeightLbs = this.totalCarryCapacity;
    return { success: true };
  }

  removeMember(id) {
    const idx = this.members.findIndex(m => m.id === id);
    if (idx <= 0) return { success: false, reason: idx === 0 ? "Cannot remove player." : "Not in party." };
    this.members.splice(idx, 1);
    this.inventory.maxWeightLbs = this.totalCarryCapacity;
    return { success: true };
  }

  addPet(pet, ownerIndex = 0) {
    this.pets.push({ pet, ownerIndex });
    if (pet.isMount) this.mountBonus += 20; // saddlebag bonus lbs
    this.inventory.maxWeightLbs = this.totalCarryCapacity;
  }

  get isAlive() { return this.player?.isAlive ?? false; }
}

// ═══════════════════════════════════════════════════════════════
// WORLD ENGINE
// ═══════════════════════════════════════════════════════════════

class WorldGrid {
  constructor(seed = Util.uid()) {
    this.seed     = seed;
    this.tiles    = new Map(); // "x,y" → GridTile
    this.dungeons = new Map(); // dungeonId → DungeonMap
    this.towns    = [];
    this.currentX = 0;
    this.currentY = 0;
    this.inDungeon = null; // { dungeonId, x, y, entryX, entryY }
  }

  tileKey(x, y) { return `${x},${y}`; }

  getTile(x, y) { return this.tiles.get(this.tileKey(x, y)) || null; }

  setTile(x, y, tile) { this.tiles.set(this.tileKey(x, y), { ...tile, x, y }); }

  get currentTile() {
    if (this.inDungeon) {
      const d = this.dungeons.get(this.inDungeon.dungeonId);
      return d?.tiles.get(this.tileKey(this.inDungeon.x, this.inDungeon.y)) || null;
    }
    return this.getTile(this.currentX, this.currentY);
  }

  /**
   * Move in a cardinal direction.
   * @returns {{ tile, newX, newY, spawned }}
   */
  move(direction) {
    const deltas = { N: [0,1], S: [0,-1], E: [1,0], W: [-1,0] };
    const [dx, dy] = deltas[direction] || [0,0];

    if (this.inDungeon) {
      this.inDungeon.x += dx;
      this.inDungeon.y += dy;
      const d = this.dungeons.get(this.inDungeon.dungeonId);
      if (!d.tiles.has(this.tileKey(this.inDungeon.x, this.inDungeon.y))) {
        const newTile = this._generateDungeonTile(this.inDungeon.x, this.inDungeon.y);
        d.tiles.set(this.tileKey(this.inDungeon.x, this.inDungeon.y), newTile);
      }
      const tile = d.tiles.get(this.tileKey(this.inDungeon.x, this.inDungeon.y));
      const spawn = this._rollSpawn(GRID_TYPES.DUNGEON_INTERIOR);
      return { tile, newX: this.inDungeon.x, newY: this.inDungeon.y, spawn };
    }

    this.currentX += dx;
    this.currentY += dy;

    if (!this.getTile(this.currentX, this.currentY)) {
      const newTile = this._generateSurfaceTile(this.currentX, this.currentY);
      this.setTile(this.currentX, this.currentY, newTile);
    }

    const tile = this.currentTile;
    const spawn = this._rollSpawn(tile.type);

    // Check dungeon entrance
    if (tile.hasDungeon && spawn === null) {
      // Player can choose to enter
    }

    return { tile, newX: this.currentX, newY: this.currentY, spawn };
  }

  enterDungeon() {
    const tile = this.currentTile;
    if (!tile?.hasDungeon) return { success: false };
    const dungeonId = tile.dungeonId || Util.uid();
    if (!this.dungeons.has(dungeonId)) {
      this.dungeons.set(dungeonId, {
        id: dungeonId, tiles: new Map(), entryX: this.currentX, entryY: this.currentY,
      });
    }
    tile.dungeonId = dungeonId;
    this.inDungeon = { dungeonId, x: 0, y: 0, entryX: this.currentX, entryY: this.currentY };
    const d = this.dungeons.get(dungeonId);
    if (!d.tiles.has("0,0")) {
      d.tiles.set("0,0", this._generateDungeonTile(0, 0));
    }
    return { success: true };
  }

  exitDungeon() {
    if (!this.inDungeon) return { success: false };
    const { entryX, entryY } = this.inDungeon;
    this.inDungeon = null;
    this.currentX = entryX;
    this.currentY = entryY;
    return { success: true, tile: this.currentTile };
  }

  _generateSurfaceTile(x, y) {
    // Prototype: actual tile content generated by AI narrative
    const distFromOrigin = Math.sqrt(x * x + y * y);
    const isProtectionZone = distFromOrigin <= 10;
    const isTown = (Math.abs(x) % 150 === 0 && Math.abs(y) % 150 === 0);
    const hasDungeon = !isProtectionZone && !isTown && Math.random() < DUNGEON_SPAWN_RATE;

    let type = GRID_TYPES.WILDERNESS;
    if (isTown)             type = GRID_TYPES.TOWN;
    else if (isProtectionZone) type = GRID_TYPES.PROTECTION;

    return {
      x, y, type, visited: true,
      hasDungeon,
      dungeonId: null,
      description: null, // filled by AI
      imageUrl: null,
      npcIds: [],
      savedAt: Date.now(),
    };
  }

  _generateDungeonTile(x, y) {
    const isExit = (x === 0 && y === 0);
    return {
      x, y,
      type: GRID_TYPES.DUNGEON_INTERIOR,
      isExit,
      description: null,
      imageUrl: null,
      savedAt: Date.now(),
    };
  }

  _rollSpawn(tileType) {
    const rates = SPAWN_RATES[tileType.toUpperCase()] || SPAWN_RATES.WILDERNESS;
    const r = Math.random();
    let acc = 0;
    for (const [type, chance] of Object.entries(rates)) {
      acc += chance;
      if (r < acc) return type === "passive" ? null : type;
    }
    return null;
  }

  /** Save world state to JSON */
  toJSON() {
    return {
      seed: this.seed,
      currentX: this.currentX,
      currentY: this.currentY,
      inDungeon: this.inDungeon,
      tiles: Array.from(this.tiles.entries()),
      towns: this.towns,
    };
  }

  static fromJSON(data) {
    const w = new WorldGrid(data.seed);
    w.currentX = data.currentX;
    w.currentY = data.currentY;
    w.inDungeon = data.inDungeon;
    w.tiles = new Map(data.tiles);
    w.towns = data.towns;
    return w;
  }
}

// ═══════════════════════════════════════════════════════════════
// ECONOMY ENGINE
// ═══════════════════════════════════════════════════════════════

const EconomyEngine = {
  /**
   * Calculate sell price for an item.
   * @param {Object} item
   * @param {Object} subStats - seller's sub-stats
   */
  sellPrice(item, subStats = {}) {
    const basePrice = this._basePrice(item);
    const durPct    = item.durability.current / item.durability.max;
    const barterMul = 1 + (subStats.barter_plus   || 0);
    const sellMul   = 1 + (subStats.sell_earnings_x || 0);
    return Math.max(1, Math.round(basePrice * durPct * barterMul * sellMul));
  },

  /**
   * Calculate buy price for an item.
   */
  buyPrice(item, subStats = {}) {
    const basePrice = this._basePrice(item);
    const buyDisc   = 1 - Math.min(0.5, subStats.buy_cost_minus || 0);
    const barterDisc = 1 - Math.min(0.3, subStats.barter_plus   || 0) * 0.5;
    return Math.max(1, Math.round(basePrice * buyDisc * barterDisc));
  },

  _basePrice(item) {
    const rarityMul = Math.pow(2, item.rarity - 1); // doubles per rarity tier
    return Math.round(10 * rarityMul);
  },
};

// ═══════════════════════════════════════════════════════════════
// COMBAT ENGINE
// ═══════════════════════════════════════════════════════════════

class CombatSession {
  constructor(party, enemies) {
    this.party     = party;
    this.enemies   = enemies; // array of Character-like objects
    this.turn      = 0;
    this.log       = [];
    this.isOver    = false;
    this.victory   = false;
  }

  /** Determine turn order by agility/speed */
  get initiative() {
    const all = [
      ...this.party.members.map(m => ({ entity: m, isPlayer: true })),
      ...this.enemies.map(e => ({ entity: e, isPlayer: false })),
    ];
    return all.sort((a, b) => b.entity.stats.agility - a.entity.stats.agility);
  }

  /**
   * Execute one round.
   * @param {Object[]} playerActions - [{ characterId, action: "attack"|"spell"|"flee", targetIdx, skillId }]
   * @returns {{ log, isOver, victory }}
   */
  executeRound(playerActions = []) {
    const order = this.initiative;
    const roundLog = [];

    for (const slot of order) {
      const { entity, isPlayer } = slot;
      if (!entity.isAlive) continue;

      if (isPlayer) {
        const action = playerActions.find(a => a.characterId === entity.id);
        if (action) {
          const result = this._executePlayerAction(entity, action);
          roundLog.push(...result.log);
        }
      } else {
        // Enemy AI: basic attack against random living party member
        const targets = this.party.members.filter(m => m.isAlive);
        if (targets.length > 0) {
          const target = targets[Util.randInt(0, targets.length - 1)];
          const sub = StatEngine.computeSubStats(entity.stats, entity.level);
          const dmgResult = DamageEngine.basicAttack(entity.weaponDamage, sub, entity.stamina, entity.level);
          target.hp = DamageEngine.applyDamage(target.hp, dmgResult.finalDamage);
          roundLog.push({
            actor: entity.name, target: target.name,
            action: "attack", damage: dmgResult.finalDamage, isCrit: dmgResult.isCrit,
            targetHp: target.hp, targetMaxHp: target.maxHp,
          });
          // Decay weapon durability
          if (entity.equipment?.mainHand) {
            ItemEngine.applyDurabilityDecay(entity.equipment.mainHand, entity.weaponMaterial);
          }
        }
      }
    }

    this.turn++;
    this.log.push({ turn: this.turn, events: roundLog });

    // Check end conditions
    if (!this.party.isAlive) {
      this.isOver = true; this.victory = false;
    } else if (this.enemies.every(e => !e.isAlive)) {
      this.isOver = true; this.victory = true;
    }

    return { log: roundLog, isOver: this.isOver, victory: this.victory };
  }

  _executePlayerAction(character, action) {
    const log = [];
    const sub = character.subStats;

    if (action.action === "attack") {
      const target = this.enemies[action.targetIdx ?? 0];
      if (!target?.isAlive) return { log };
      const dmg = DamageEngine.basicAttack(character.weaponDamage, sub, character.stamina, character.level);
      target.hp = DamageEngine.applyDamage(target.hp, dmg.finalDamage);
      // Decay
      if (character.equipment.mainHand) {
        ItemEngine.applyDurabilityDecay(character.equipment.mainHand, character.weaponMaterial);
      }
      log.push({ actor: character.name, target: target.name, action: "attack", damage: dmg.finalDamage, isCrit: dmg.isCrit, targetHp: target.hp });
    }

    if (action.action === "spell" && action.skillId) {
      const skill = character.skills.find(s => s.id === action.skillId);
      if (!skill) return { log };
      const costPct = skill.costPct || 0.1;
      const magicCost = Math.round(character.maxMagic * costPct);
      if (character.magic < magicCost) {
        log.push({ actor: character.name, action: "spell_fail", reason: "Not enough magic." });
        return { log };
      }
      character.magic = Math.max(0, character.magic - magicCost);
      const target = this.enemies[action.targetIdx ?? 0];
      if (!target?.isAlive) return { log };
      const dmg = DamageEngine.spellAttack({ costPct, magicPool: character.maxMagic, baseSpellDmg: skill.baseDamage || 0, subStats: sub });
      target.hp = DamageEngine.applyDamage(target.hp, dmg.finalDamage);
      log.push({ actor: character.name, target: target.name, action: "spell", skillName: skill.name, damage: dmg.finalDamage, isCrit: dmg.isCrit, targetHp: target.hp });
    }

    if (action.action === "flee") {
      const checkResult = DiceEngine.rollCheck(character.stats.agility, character.level, DIFFICULTY.NORMAL);
      log.push({ actor: character.name, action: "flee", ...checkResult });
      if (checkResult.success) {
        this.isOver = true; this.victory = false; // fled
        log.push({ actor: character.name, action: "fled_successfully" });
      }
    }

    return { log };
  }

  /** Compute loot drops after victory */
  computeLoot(magicFindBonus = 0) {
    return this.enemies.map(enemy => {
      const rarity = ItemEngine.rollRarity(magicFindBonus);
      const gold   = Util.randInt(1, 10) * rarity * CURRENCY.COPPER;
      return { enemyName: enemy.name, rarity, goldDropped: gold };
    });
  }
}

// ═══════════════════════════════════════════════════════════════
// SAVE / LOAD ENGINE
// ═══════════════════════════════════════════════════════════════

const SaveEngine = {
  SLOT_COUNT: 4,
  STORAGE_KEY_PREFIX: "dawn_rpg_slot_",

  save(slotIndex, party, world) {
    if (slotIndex < 0 || slotIndex >= this.SLOT_COUNT) return { success: false };
    const data = {
      version:   ENGINE_VERSION,
      savedAt:   Date.now(),
      party: {
        members:   party.members.map(m => m.toJSON()),
        pets:      party.pets.map(p => ({ pet: p.pet.toJSON(), ownerIndex: p.ownerIndex })),
        inventory: party.inventory.toJSON(),
        mountBonus: party.mountBonus,
      },
      world: world.toJSON(),
    };
    try {
      localStorage.setItem(this.STORAGE_KEY_PREFIX + slotIndex, JSON.stringify(data));
      return { success: true };
    } catch (e) {
      return { success: false, reason: e.message };
    }
  },

  load(slotIndex) {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY_PREFIX + slotIndex);
      if (!raw) return null;
      const data = JSON.parse(raw);
      const party = new Party();
      data.party.members.forEach(m => party.members.push(Character.fromJSON(m)));
      data.party.pets.forEach(p => party.pets.push({ pet: Character.fromJSON(p.pet), ownerIndex: p.ownerIndex }));
      party.inventory = Inventory.fromJSON(data.party.inventory);
      party.mountBonus = data.party.mountBonus || 0;
      const world = WorldGrid.fromJSON(data.world);
      return { party, world, savedAt: data.savedAt };
    } catch (e) {
      console.error("Save load error:", e);
      return null;
    }
  },

  listSlots() {
    return Array.from({ length: this.SLOT_COUNT }, (_, i) => {
      try {
        const raw = localStorage.getItem(this.STORAGE_KEY_PREFIX + i);
        if (!raw) return { index: i, empty: true };
        const data = JSON.parse(raw);
        const player = data.party.members[0];
        return {
          index: i, empty: false,
          characterName: player?.name || "Unknown",
          level:         player?.level || 1,
          location:      data.world?.currentX + "," + data.world?.currentY,
          savedAt:       data.savedAt,
        };
      } catch { return { index: i, empty: true }; }
    });
  },

  deleteSlot(slotIndex) {
    localStorage.removeItem(this.STORAGE_KEY_PREFIX + slotIndex);
  },
};

// ═══════════════════════════════════════════════════════════════
// GAME STATE MANAGER  (top-level singleton)
// ═══════════════════════════════════════════════════════════════

class GameState {
  constructor() {
    this.party        = null;
    this.world        = null;
    this.combat       = null;     // active CombatSession or null
    this.currentSlot  = 0;
    this.inCombat     = false;
    this.listeners    = {};       // event → [fn]
  }

  on(event, fn) {
    (this.listeners[event] = this.listeners[event] || []).push(fn);
  }

  emit(event, data) {
    (this.listeners[event] || []).forEach(fn => fn(data));
  }

  /** Start a brand new game from character creator data */
  newGame(creatorData, slotIndex = 0) {
    const player = new Character({
      ...creatorData.character,
      stats: creatorData.playerStats,
      level: 1,
    });

    const pet = new Character({
      name:       creatorData.petName,
      species:    creatorData.petSpecies,
      appearance: { aura: creatorData.petAppearance },
      personality: creatorData.petPersonality,
      petBond:    creatorData.petBond,
      stats:      creatorData.petStats,
      level:      1,
      isPet:      true,
    });

    this.party = new Party();
    this.party.addMember(player);
    this.party.addPet(pet, 0);

    // Starter currency
    const starterCopper = { poor: 50, common: 10, modest: 50, comfortable: 100 }[creatorData.startingCurrency] || 10;
    this.party.inventory.addCurrency(starterCopper);

    // Add starter items
    if (creatorData.startingWeapon) {
      const weapon = ItemEngine.createItem({
        name: creatorData.startingWeapon,
        type: "weapon",
        icon: "⚔",
        description: `${creatorData.startingWeapon}. A humble but serviceable starting weapon.`,
        rarity: 1,
        weaponDmg: 15,
        weightLbs: 2,
      });
      this.party.inventory.addItem(weapon);
      player.equip("mainHand", weapon);
    }

    this.world = new WorldGrid();
    // Set starting tile
    this.world.setTile(0, 0, {
      x: 0, y: 0, type: GRID_TYPES.WILDERNESS,
      hasDungeon: false, description: null, imageUrl: null, npcIds: [], savedAt: Date.now(), visited: true,
    });

    this.currentSlot = slotIndex;
    this.autosave();
    this.emit("gameStarted", { player, pet });
    return { player, pet };
  }

  /** Move in a direction, trigger events */
  move(direction) {
    if (this.inCombat) return { success: false, reason: "Cannot move during combat." };
    const result = this.world.move(direction);
    this.autosave();
    this.emit("moved", result);

    if (result.spawn && result.spawn !== "passive") {
      this.emit("encounterSpawned", { spawnType: result.spawn, tile: result.tile });
    }

    return result;
  }

  /** Start a combat encounter */
  startCombat(enemies) {
    this.combat   = new CombatSession(this.party, enemies);
    this.inCombat = true;
    this.emit("combatStarted", { enemies });
  }

  /** Submit player actions for the round */
  submitCombatRound(playerActions) {
    if (!this.combat) return null;
    const result = this.combat.executeRound(playerActions);
    if (result.isOver) {
      this.inCombat = false;
      if (result.victory) {
        const loot = this.combat.computeLoot(this.party.player?.subStats?.magic_find_plus || 0);
        this.emit("combatVictory", { loot });
      } else {
        this.emit("combatDefeated", {});
      }
    }
    this.emit("combatRound", result);
    return result;
  }

  /** Perform a skill check */
  skillCheck(statKey, difficulty = DIFFICULTY.NORMAL) {
    const player = this.party?.player;
    if (!player) return null;
    const stat = player.stats[statKey] || BASE_STAT;
    return DiceEngine.rollCheck(stat, player.level, difficulty);
  }

  autosave() {
    if (this.party && this.world) {
      SaveEngine.save(this.currentSlot, this.party, this.world);
    }
  }

  save(slotIndex = this.currentSlot) {
    return SaveEngine.save(slotIndex, this.party, this.world);
  }

  load(slotIndex) {
    const data = SaveEngine.load(slotIndex);
    if (!data) return { success: false };
    this.party       = data.party;
    this.world       = data.world;
    this.currentSlot = slotIndex;
    this.inCombat    = false;
    this.emit("gameLoaded", data);
    return { success: true };
  }
}

// ═══════════════════════════════════════════════════════════════
// EXPORTS  (works in both browser globals and module contexts)
// ═══════════════════════════════════════════════════════════════

const DawnEngine = {
  VERSION: ENGINE_VERSION,
  // Core systems
  Util,
  DiceEngine,
  StatEngine,
  DamageEngine,
  ItemEngine,
  EconomyEngine,
  // Classes
  Inventory,
  Character,
  Party,
  WorldGrid,
  CombatSession,
  SaveEngine,
  GameState,
  // Constants
  DIFFICULTY,
  RARITY,
  SPAWN_RATES,
  GRID_TYPES,
  CURRENCY,
  MAX_LEVEL,
  BASE_STAT,
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = DawnEngine;
} else {
  window.DawnEngine = DawnEngine;
}
