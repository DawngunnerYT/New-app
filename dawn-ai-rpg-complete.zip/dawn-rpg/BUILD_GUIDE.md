# Dawn AI RPG — APK Build Guide
Complete instructions to go from source files → signed Android APK/AAB.

---

## Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 18+ | https://nodejs.org |
| Java JDK | 17+ | https://adoptium.net |
| Android Studio | Hedgehog+ | https://developer.android.com/studio |
| Android SDK | API 34 | via Android Studio SDK Manager |
| Gradle | 8.x | bundled with Android Studio |

---

## Project Structure

```
dawn-rpg/
├── www/                    ← Web app (your actual game)
│   ├── index.html          ← Entry point (all screens)
│   ├── js/
│   │   ├── engine.js       ← Game logic & math engine
│   │   ├── ai.js           ← AI integration layer
│   │   └── app.js          ← UI controller / wiring
│   └── assets/             ← Icons, splash screens
├── android/                ← Capacitor-generated Android project
│   ├── app/
│   │   ├── build.gradle    ← App-level Gradle config
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       └── java/com/dawnai/rpg/
│   │           └── MainActivity.java
│   └── build.gradle        ← Project-level Gradle
├── capacitor.config.ts     ← Capacitor settings
└── package.json
```

---

## Step 1 — Install Dependencies

```bash
cd dawn-rpg
npm install
```

---

## Step 2 — Initialize Capacitor

```bash
# Init Capacitor with your app details
npx cap init "Dawn AI RPG" com.dawnai.rpg --web-dir www

# Add Android platform
npx cap add android
```

---

## Step 3 — Copy Custom Native Files

After `cap add android` generates the Android project, replace/merge these files:

```bash
# Copy your custom MainActivity
cp android/app/src/main/java/com/dawnai/rpg/MainActivity.java \
   android/app/src/main/java/com/dawnai/rpg/MainActivity.java

# Copy your custom AndroidManifest
cp android/AndroidManifest.xml \
   android/app/src/main/AndroidManifest.xml

# Copy your custom build.gradle
cp android/app/build.gradle \
   android/app/build.gradle
```

---

## Step 4 — Configure Cross-Origin Isolation (for WebLLM)

WebLLM requires `SharedArrayBuffer`, which needs COOP/COEP headers.
Create this file so Capacitor serves the right headers:

**File: `android/app/src/main/assets/public/_headers`**
```
/*
  Cross-Origin-Embedder-Policy: require-corp
  Cross-Origin-Opener-Policy: same-origin
```

Also update `android/app/src/main/java/com/dawnai/rpg/MainActivity.java`
to ensure the `WebViewAssetLoader` is configured (Capacitor handles this automatically
for localhost serving).

---

## Step 5 — Sync Web Assets to Android

```bash
npx cap sync android
```

This copies your `www/` folder into `android/app/src/main/assets/public/`.

---

## Step 6 — Open in Android Studio

```bash
npx cap open android
```

Android Studio will open. Wait for Gradle sync to complete.

---

## Step 7 — Test on Device / Emulator

### Using Android Studio:
1. Connect your Android device via USB (enable Developer Mode + USB Debugging)
2. Click **Run ▶** in Android Studio
3. Select your device

### Using CLI:
```bash
npx cap run android
```

### Live Reload (for development):
```bash
# Find your local IP
ifconfig | grep inet

# Update capacitor.config.ts:
# server: { url: "http://YOUR_IP:3000", cleartext: true }

npx cap run android --livereload --external
```

---

## Step 8 — Build Release APK

### Generate a Keystore (one-time setup)

```bash
keytool -genkey -v \
  -keystore dawn-rpg-release.keystore \
  -alias dawn-rpg \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

Save the keystore file securely. Never commit it to version control.

### Configure Signing in `android/app/build.gradle`

Uncomment and fill in the `signingConfigs` block:

```groovy
android {
    signingConfigs {
        release {
            storeFile     file("/path/to/dawn-rpg-release.keystore")
            storePassword "YOUR_STORE_PASSWORD"
            keyAlias      "dawn-rpg"
            keyPassword   "YOUR_KEY_PASSWORD"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
        }
    }
}
```

### Build the APK

```bash
cd android
./gradlew assembleRelease
```

Output: `android/app/build/outputs/apk/release/app-release.apk`

### Build AAB (for Google Play)

```bash
cd android
./gradlew bundleRelease
```

Output: `android/app/build/outputs/bundle/release/app-release.aab`

---

## Step 9 — Install APK to Device

```bash
adb install android/app/build/outputs/apk/release/app-release.apk
```

---

## WebLLM Model Notes

WebLLM downloads the model to the browser's cache on first run.
Model size varies:

| Model | Size | RAM Required | Best For |
|-------|------|-------------|---------|
| `Llama-3.2-1B-Instruct-q4f32_1-MLC` | ~700MB | 2GB | Low-end devices |
| `Llama-3.1-8B-Instruct-q4f32_1-MLC` | ~4GB | 6GB | Mid-range devices |
| `Phi-3.5-mini-instruct-q4f16_1-MLC` | ~2GB | 4GB | Balanced |

To change the model, update `webLLMModel` in `www/js/app.js`:
```javascript
narrative: {
  webLLMModel: "Phi-3.5-mini-instruct-q4f16_1-MLC",
  ...
}
```

**Recommended minimum device specs for WebLLM:**
- Android 10+ (API 29+)
- 6GB RAM
- GPU with Vulkan 1.1 support
- 8GB free storage (for model cache)

**Fallback**: If the device doesn't support WebGPU/WebLLM, the AI layer
automatically falls back to the mock response engine. Add a Claude API key
in `app.js` to enable the Claude API fallback on unsupported devices.

---

## Google Play Submission

1. Build AAB: `./gradlew bundleRelease`
2. Sign with your keystore (configured above)
3. Go to [Google Play Console](https://play.google.com/console)
4. Create new app → Upload AAB
5. Complete store listing (screenshots, description, rating questionnaire)
6. Content rating: T (Teen) — Fantasy Violence

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `SharedArrayBuffer not defined` | Add COOP/COEP headers, ensure serving from localhost |
| `WebGPU not supported` | Device too old; use mock or Claude API fallback |
| `Gradle build failed` | Run `./gradlew --stacktrace` for details |
| `adb: device not found` | Enable USB debugging, try `adb kill-server && adb start-server` |
| App crashes on startup | Check `adb logcat` for Java errors |
| WebLLM download fails | Check internet permission in manifest; try different model |
| Fonts not loading | Add fonts to `www/assets/` and serve locally (no Google Fonts CDN offline) |

---

## Optional Enhancements

```bash
# Haptic feedback on dice rolls
npm install @capacitor/haptics

# Keep screen awake during AI generation  
npm install @capacitor-community/keep-awake

# Local push notifications (quest reminders)
npm install @capacitor/local-notifications

# Background audio (ambient music)
npm install @capacitor/background-runner
```

After installing any plugin, run `npx cap sync android` and rebuild.
