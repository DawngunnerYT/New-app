import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId:    'com.dawnai.rpg',
  appName:  'Dawn AI RPG',
  webDir:   'www',

  // ── Android-specific settings ──────────────────────────────
  android: {
    // Allow WebGPU / WebLLM to work inside the WebView
    allowMixedContent: false,
    captureInput:      true,
    webContentsDebuggingEnabled: false, // set true during dev

    // Custom back button handling (prevent accidental exit)
    handleApplicationNotifications: true,

    // Keep screen awake during AI generation
    // (requires @capacitor-community/keep-awake plugin if needed)
  },

  // ── Plugin configuration ───────────────────────────────────
  plugins: {
    SplashScreen: {
      launchShowDuration:    2000,
      launchAutoHide:        true,
      backgroundColor:       "#0a0908",
      androidSplashResourceName: "splash",
      androidScaleType:      "CENTER_CROP",
      showSpinner:           false,
      splashFullScreen:      true,
      splashImmersive:       true,
    },

    StatusBar: {
      style:           "DARK",
      backgroundColor: "#0a0908",
      overlaysWebView: false,
    },

    Keyboard: {
      resize:          "body",
      style:           "dark",
      resizeOnFullScreen: true,
    },
  },

  // ── Server (for live-reload during dev) ────────────────────
  // Uncomment during development:
  // server: {
  //   url: "http://YOUR_LOCAL_IP:3000",
  //   cleartext: true,
  // },
};

export default config;
