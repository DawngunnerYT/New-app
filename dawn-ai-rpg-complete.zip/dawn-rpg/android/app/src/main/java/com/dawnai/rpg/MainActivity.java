package com.dawnai.rpg;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.BridgeActivity;

/**
 * Dawn AI RPG — MainActivity
 *
 * Extends Capacitor's BridgeActivity to retain all plugin support.
 * Adds WebView configuration for WebGPU / WebLLM and full-screen immersive mode.
 */
public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Full-screen immersive mode ──────────────────────
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE            |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION   |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN        |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION          |
            View.SYSTEM_UI_FLAG_FULLSCREEN               |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        // ── Keep screen on during AI generation ─────────────
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // ── WebView configuration for WebGPU / WebLLM ───────
        configureWebView();
    }

    private void configureWebView() {
        WebView webView = getBridge().getWebView();
        if (webView == null) return;

        WebSettings settings = webView.getSettings();

        // ── Core settings ───────────────────────────────────
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);   // localStorage for save slots
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // ── Memory for large model loading ──────────────────
        // Increase cache for WebLLM model weights (can be ~4GB)
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAppCacheEnabled(true);

        // ── Hardware acceleration (required for WebGPU) ─────
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // ── WebGL / WebGPU flags ────────────────────────────
        // These flags enable GPU-accelerated inference in WebLLM
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            // Android 8.0+: Enable modern WebView features
            settings.setSafeBrowsingEnabled(false); // avoid interference
        }

        // ── Debugging (disable for production) ──────────────
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // ── Mixed content (HTTPS image URLs from Pollinations) ─
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // ── Prevent text selection on long press (RPG UX) ───
        webView.setOnLongClickListener(v -> true);
        webView.setLongClickable(false);

        // ── Custom WebViewClient ─────────────────────────────
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep all navigation inside the app
                view.loadUrl(url);
                return true;
            }
        });

        // ── SharedArrayBuffer (required by WebLLM) ──────────
        // Note: WebLLM requires SharedArrayBuffer + COOP/COEP headers.
        // Since we're in a Capacitor app (file:// origin), we inject
        // the necessary headers via the custom protocol handler below.
        setupSharedArrayBuffer(webView);
    }

    /**
     * WebLLM requires SharedArrayBuffer which needs Cross-Origin isolation.
     * In a Capacitor context we override the WebView's HTTP handler to
     * add the necessary headers to all local asset responses.
     */
    private void setupSharedArrayBuffer(WebView webView) {
        // Capacitor handles file:// loading internally.
        // The getBridge().setServerBasePath() approach ensures
        // the app is served from localhost, enabling COOP/COEP via
        // the custom WebViewAssetLoader configured in the capacitor bridge.
        //
        // If WebLLM still fails, add to android/app/src/main/assets/public/_headers:
        //   Cross-Origin-Embedder-Policy: require-corp
        //   Cross-Origin-Opener-Policy: same-origin
        //
        // OR use the Capacitor Community HTTP plugin to proxy requests with headers.
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // Re-apply immersive mode when window regains focus (e.g. after notification)
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE            |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION   |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN        |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION          |
                View.SYSTEM_UI_FLAG_FULLSCREEN               |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    @Override
    public void onBackPressed() {
        // Intercept back button — let JavaScript handle it (pause menu, etc.)
        WebView webView = getBridge().getWebView();
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            // Optionally show a "quit?" dialog instead of immediately exiting
            super.onBackPressed();
        }
    }
}
